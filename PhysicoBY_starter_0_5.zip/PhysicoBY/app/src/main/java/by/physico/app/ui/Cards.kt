package by.physico.app.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import by.physico.app.data.Formula
import by.physico.app.ui.theme.PhysicoColors

/** Formula flash cards: look at the name, recall the formula, then check yourself. */
@Composable
fun CardRunner(
    title: String,
    cards: List<Formula>,
    favorites: Set<String>,
    onAnswer: (String, Boolean) -> Unit,
    onToggleFavorite: (String) -> Unit,
    onExit: () -> Unit
) {
    var index by remember { mutableIntStateOf(0) }
    var flipped by remember { mutableStateOf(false) }
    var known by remember { mutableIntStateOf(0) }
    val total = cards.size
    val done = index >= total
    val cs = MaterialTheme.colorScheme
    val ex = PhysicoColors.extra

    BackHandler { onExit() }

    Column(modifier = Modifier.fillMaxSize()) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onExit) {
                Icon(Icons.Filled.Close, contentDescription = "Закрыть")
            }
            ProgressBar(
                fraction = index.toFloat() / total.coerceAtLeast(1),
                modifier = Modifier.weight(1f)
            )
            Spacer(Modifier.width(12.dp))
            Text(
                text = (minOf(index + 1, total)).toString() + "/" + total.toString(),
                color = cs.onSurfaceVariant,
                fontWeight = FontWeight.Bold
            )
            Spacer(Modifier.width(8.dp))
        }

        Box(modifier = Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.TopCenter) {
            Column(
                modifier = Modifier
                    .widthIn(max = 640.dp)
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Text(text = title, style = MaterialTheme.typography.labelLarge, color = cs.primary)
                if (!done) {
                    val card = cards[index]
                    val isFavorite = favorites.contains(card.id)
                    AppCard(
                        onClick = { flipped = !flipped },
                        containerColor = if (flipped) cs.primaryContainer else cs.surface,
                        borderColor = if (flipped) cs.primary else cs.outlineVariant
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = if (flipped) "Формула" else "Вспомни формулу",
                                style = MaterialTheme.typography.labelLarge,
                                color = cs.onSurfaceVariant,
                                modifier = Modifier.weight(1f)
                            )
                            Text(
                                text = if (isFavorite) "⭐" else "☆",
                                style = MaterialTheme.typography.headlineSmall,
                                modifier = Modifier.padding(4.dp),
                                color = ex.gold
                            )
                        }
                        Spacer(Modifier.height(12.dp))
                        Text(
                            text = card.title,
                            style = MaterialTheme.typography.headlineSmall,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.fillMaxWidth()
                        )
                        Spacer(Modifier.height(16.dp))
                        if (flipped) {
                            Text(
                                text = card.expression,
                                style = MaterialTheme.typography.headlineMedium,
                                color = cs.onPrimaryContainer,
                                textAlign = TextAlign.Center,
                                modifier = Modifier.fillMaxWidth()
                            )
                            Spacer(Modifier.height(12.dp))
                            Text(
                                text = card.legend,
                                style = MaterialTheme.typography.bodyMedium,
                                color = cs.onPrimaryContainer,
                                textAlign = TextAlign.Center,
                                modifier = Modifier.fillMaxWidth()
                            )
                        } else {
                            Text(
                                text = "Нажми на карточку, чтобы проверить себя",
                                style = MaterialTheme.typography.bodyMedium,
                                color = cs.onSurfaceVariant,
                                textAlign = TextAlign.Center,
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                    }
                    SecondaryButton(
                        text = if (isFavorite) "Убрать из избранного" else "⭐ В избранное",
                        onClick = { onToggleFavorite(card.id) }
                    )
                } else {
                    AppCard(containerColor = ex.successContainer, borderColor = ex.success) {
                        Text(
                            text = "Готово! 🎉",
                            style = MaterialTheme.typography.headlineSmall,
                            color = ex.onSuccessContainer
                        )
                        Spacer(Modifier.height(8.dp))
                        Text(
                            text = "Знаешь: " + known.toString() + " из " + total.toString() +
                                ". Карточки, которые ты отметил как «Повторить», вернутся в повторение сегодня.",
                            color = ex.onSuccessContainer
                        )
                    }
                }
            }
        }

        Surface(tonalElevation = 3.dp, modifier = Modifier.fillMaxWidth()) {
            Box(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(modifier = Modifier.widthIn(max = 640.dp)) {
                    if (done) {
                        PrimaryButton(text = "Закрыть", onClick = onExit)
                    } else if (!flipped) {
                        PrimaryButton(text = "Показать формулу", onClick = { flipped = true })
                    } else {
                        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            SecondaryButton(
                                text = "Повторить 🔁",
                                onClick = {
                                    onAnswer(cards[index].id, false)
                                    index += 1
                                    flipped = false
                                },
                                modifier = Modifier.weight(1f)
                            )
                            PrimaryButton(
                                text = "Знаю ✅",
                                onClick = {
                                    onAnswer(cards[index].id, true)
                                    known += 1
                                    index += 1
                                    flipped = false
                                },
                                modifier = Modifier.weight(1f),
                                container = ex.success,
                                content = ex.onSuccess
                            )
                        }
                    }
                }
            }
        }
    }
}
