package by.physico.app.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight

private val LightColors = lightColorScheme(
    primary = Color(0xFF4F46E5),
    onPrimary = Color(0xFFFFFFFF),
    primaryContainer = Color(0xFFE3E1FF),
    onPrimaryContainer = Color(0xFF1B1464),
    secondary = Color(0xFF0E9AA7),
    onSecondary = Color(0xFFFFFFFF),
    secondaryContainer = Color(0xFFD3F4F7),
    onSecondaryContainer = Color(0xFF00363B),
    tertiary = Color(0xFFF97316),
    onTertiary = Color(0xFFFFFFFF),
    tertiaryContainer = Color(0xFFFFEDD5),
    onTertiaryContainer = Color(0xFF5A2A00),
    background = Color(0xFFF6F7FB),
    onBackground = Color(0xFF1B1B21),
    surface = Color(0xFFFFFFFF),
    onSurface = Color(0xFF1B1B21),
    surfaceVariant = Color(0xFFEDEEF6),
    onSurfaceVariant = Color(0xFF55596A),
    outline = Color(0xFF8A8FA3),
    outlineVariant = Color(0xFFDADCE8),
    error = Color(0xFFD93025),
    onError = Color(0xFFFFFFFF),
    errorContainer = Color(0xFFFDE2E0),
    onErrorContainer = Color(0xFF5A0B07),
    surfaceContainerLowest = Color(0xFFFFFFFF),
    surfaceContainerLow = Color(0xFFF9F9FD),
    surfaceContainer = Color(0xFFF1F2F8),
    surfaceContainerHigh = Color(0xFFEBECF4),
    surfaceContainerHighest = Color(0xFFE5E7F0)
)

private val DarkColors = darkColorScheme(
    primary = Color(0xFFB4B0FF),
    onPrimary = Color(0xFF2B2480),
    primaryContainer = Color(0xFF3A33B8),
    onPrimaryContainer = Color(0xFFE3E1FF),
    secondary = Color(0xFF5FD4DF),
    onSecondary = Color(0xFF00363B),
    secondaryContainer = Color(0xFF004F55),
    onSecondaryContainer = Color(0xFFD3F4F7),
    tertiary = Color(0xFFFFB27A),
    onTertiary = Color(0xFF4A2000),
    tertiaryContainer = Color(0xFF6B3200),
    onTertiaryContainer = Color(0xFFFFEDD5),
    background = Color(0xFF111218),
    onBackground = Color(0xFFE4E4EC),
    surface = Color(0xFF1A1B24),
    onSurface = Color(0xFFE4E4EC),
    surfaceVariant = Color(0xFF2A2C3A),
    onSurfaceVariant = Color(0xFFC2C5D6),
    outline = Color(0xFF8D90A3),
    outlineVariant = Color(0xFF3F4252),
    error = Color(0xFFFF8A80),
    onError = Color(0xFF5A0B07),
    errorContainer = Color(0xFF7A1A14),
    onErrorContainer = Color(0xFFFFDAD6),
    surfaceContainerLowest = Color(0xFF0C0D12),
    surfaceContainerLow = Color(0xFF161720),
    surfaceContainer = Color(0xFF1B1C26),
    surfaceContainerHigh = Color(0xFF242530),
    surfaceContainerHighest = Color(0xFF2E2F3B)
)

@Immutable
data class ExtraColors(
    val success: Color,
    val onSuccess: Color,
    val successContainer: Color,
    val onSuccessContainer: Color,
    val gold: Color
)

private val LightExtras = ExtraColors(
    success = Color(0xFF15803D),
    onSuccess = Color(0xFFFFFFFF),
    successContainer = Color(0xFFDCFCE7),
    onSuccessContainer = Color(0xFF14532D),
    gold = Color(0xFFF5B301)
)

private val DarkExtras = ExtraColors(
    success = Color(0xFF4ADE80),
    onSuccess = Color(0xFF052E16),
    successContainer = Color(0xFF14532D),
    onSuccessContainer = Color(0xFFDCFCE7),
    gold = Color(0xFFFFD54F)
)

val LocalExtraColors = staticCompositionLocalOf { LightExtras }

object PhysicoColors {
    val extra: ExtraColors
        @Composable get() = LocalExtraColors.current
}

private val BaseTypography = Typography()

private val PhysicoTypography = BaseTypography.copy(
    headlineMedium = BaseTypography.headlineMedium.copy(fontWeight = FontWeight.Bold),
    headlineSmall = BaseTypography.headlineSmall.copy(fontWeight = FontWeight.Bold),
    titleLarge = BaseTypography.titleLarge.copy(fontWeight = FontWeight.Bold),
    titleMedium = BaseTypography.titleMedium.copy(fontWeight = FontWeight.SemiBold),
    titleSmall = BaseTypography.titleSmall.copy(fontWeight = FontWeight.SemiBold),
    labelLarge = BaseTypography.labelLarge.copy(fontWeight = FontWeight.SemiBold)
)

@Composable
fun PhysicoTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    CompositionLocalProvider(
        LocalExtraColors provides (if (darkTheme) DarkExtras else LightExtras)
    ) {
        MaterialTheme(
            colorScheme = if (darkTheme) DarkColors else LightColors,
            typography = PhysicoTypography,
            content = content
        )
    }
}
