package by.physico.app.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.sp
import by.physico.app.data.CharacterStage
import by.physico.app.data.Gender

private val SkinColor = Color(0xFFFFDCC2)
private val InkColor = Color(0xFF2B2B3A)
private val MouthColor = Color(0xFF8B4A4A)

private val StageBackground = listOf(
    Color(0xFF9AA5B8), Color(0xFFA5D6A7), Color(0xFF90CAF9), Color(0xFFCE93D8), Color(0xFFFFD54F)
)
private val StageShirt = listOf(
    Color(0xFF7C8596), Color(0xFF43A047), Color(0xFF1E88E5), Color(0xFF37474F), Color(0xFFF5F7FA)
)

/**
 * Anime-style character drawn with Canvas primitives.
 * Coordinates are expressed on a 100 x 100 grid and scaled to the requested size.
 */
@Composable
fun CharacterAvatar(
    gender: Gender,
    stage: CharacterStage,
    size: Dp,
    modifier: Modifier = Modifier,
    showBadge: Boolean = true
) {
    Box(
        modifier = modifier.size(size).clip(CircleShape),
        contentAlignment = Alignment.TopEnd
    ) {
        Canvas(modifier = Modifier.size(size)) {
            drawCharacter(gender, stage.ordinal)
        }
        if (showBadge) {
            Text(
                text = stage.emoji,
                fontSize = (size.value * 0.2f).sp,
                modifier = Modifier.alpha(0.95f)
            )
        }
    }
}

private fun DrawScope.drawCharacter(gender: Gender, stage: Int) {
    val u = size.minDimension / 100f
    fun p(x: Float, y: Float): Offset = Offset(x * u, y * u)
    fun sz(w: Float, h: Float): Size = Size(w * u, h * u)

    fun oval(x: Float, y: Float, w: Float, h: Float, color: Color) {
        drawOval(color = color, topLeft = p(x, y), size = sz(w, h))
    }

    fun poly(color: Color, vararg pts: Float) {
        val path = Path()
        var i = 0
        while (i + 1 < pts.size) {
            if (i == 0) path.moveTo(pts[i] * u, pts[i + 1] * u)
            else path.lineTo(pts[i] * u, pts[i + 1] * u)
            i += 2
        }
        path.close()
        drawPath(path = path, color = color)
    }

    fun line(x1: Float, y1: Float, x2: Float, y2: Float, color: Color, width: Float) {
        drawLine(color = color, start = p(x1, y1), end = p(x2, y2), strokeWidth = width * u, cap = StrokeCap.Round)
    }

    fun arc(x: Float, y: Float, w: Float, h: Float, start: Float, sweep: Float, color: Color, width: Float) {
        drawArc(
            color = color,
            startAngle = start,
            sweepAngle = sweep,
            useCenter = false,
            topLeft = p(x, y),
            size = sz(w, h),
            style = Stroke(width = width * u, cap = StrokeCap.Round)
        )
    }

    val isFemale = gender == Gender.FEMALE
    val hair = if (isFemale) Color(0xFF8A4FD1) else Color(0xFF263259)
    val iris = if (isFemale) Color(0xFFC2428F) else Color(0xFF3A7BD5)

    // background
    drawRect(color = StageBackground[stage], size = size)

    // long hair behind the head
    if (isFemale) {
        drawRoundRect(
            color = hair,
            topLeft = p(22f, 20f),
            size = sz(56f, 66f),
            cornerRadius = CornerRadius(22f * u, 22f * u)
        )
    }

    // body
    oval(12f, 74f, 76f, 60f, StageShirt[stage])
    if (stage == 2) {
        poly(Color.White, 38f, 75f, 49f, 75f, 50f, 86f)
        poly(Color.White, 62f, 75f, 51f, 75f, 50f, 86f)
        poly(Color(0xFFE53935), 48f, 80f, 52f, 80f, 53f, 94f, 50f, 98f, 47f, 94f)
    }
    if (stage == 3) {
        poly(Color(0xFFECEFF1), 40f, 75f, 60f, 75f, 50f, 92f)
        poly(Color(0xFF263238), 36f, 76f, 44f, 76f, 50f, 92f, 40f, 88f)
        poly(Color(0xFF263238), 64f, 76f, 56f, 76f, 50f, 92f, 60f, 88f)
    }
    if (stage == 4) {
        poly(Color(0xFF1E88E5), 40f, 76f, 60f, 76f, 50f, 94f)
        poly(Color.White, 36f, 74f, 48f, 74f, 50f, 92f, 40f, 84f)
        poly(Color.White, 64f, 74f, 52f, 74f, 50f, 92f, 60f, 84f)
        line(36f, 74f, 50f, 92f, Color(0xFFB0BEC5), 0.8f)
        line(64f, 74f, 50f, 92f, Color(0xFFB0BEC5), 0.8f)
    }

    // neck, ears, head
    drawRoundRect(
        color = SkinColor,
        topLeft = p(44f, 64f),
        size = sz(12f, 16f),
        cornerRadius = CornerRadius(3f * u, 3f * u)
    )
    oval(24f, 46f, 8f, 10f, SkinColor)
    oval(68f, 46f, 8f, 10f, SkinColor)
    oval(28f, 24f, 44f, 48f, SkinColor)

    // hair bun for the final stage
    if (stage == 4 && isFemale) {
        oval(43f, 6f, 14f, 14f, hair)
    }

    // bangs
    poly(
        hair,
        27f, 48f, 25f, 36f, 30f, 26f, 40f, 19f, 50f, 17f, 60f, 19f, 70f, 26f, 75f, 36f, 73f, 48f,
        68f, 38f, 63f, 31f, 58f, 40f, 52f, 30f, 47f, 40f, 42f, 31f, 36f, 40f, 32f, 48f
    )
    if (isFemale) {
        poly(hair, 27f, 44f, 34f, 44f, 33f, 66f, 25f, 76f)
        poly(hair, 73f, 44f, 66f, 44f, 67f, 66f, 75f, 76f)
    }
    if (stage == 1) {
        poly(hair, 47f, 19f, 44f, 8f, 53f, 18f)
    }
    if (stage == 0) {
        poly(hair, 34f, 26f, 27f, 12f, 43f, 22f)
        poly(hair, 48f, 19f, 54f, 5f, 60f, 19f)
        poly(hair, 62f, 22f, 75f, 13f, 71f, 33f)
        poly(hair, 27f, 36f, 14f, 32f, 28f, 48f)
        poly(hair, 73f, 38f, 86f, 35f, 74f, 50f)
    }

    // eyes
    val eyeCenters = listOf(40f, 60f)
    for (cx in eyeCenters) {
        oval(cx - 5.5f, 43f, 11f, 14f, InkColor)
        oval(cx - 4.5f, 44.5f, 9f, 12f, iris)
        oval(cx - 2.2f, 48f, 4.4f, 6.5f, Color(0xFF1B1B3A))
        oval(cx - 3.6f, 45.5f, 3.4f, 3.4f, Color.White)
        oval(cx + 0.8f, 52.5f, 1.8f, 1.8f, Color(0xE6FFFFFF))
        if (stage == 0) {
            // sleepy eyelids and tired bags under the eyes
            drawRect(color = SkinColor, topLeft = p(cx - 6.5f, 42f), size = sz(13f, 8f))
            line(cx - 6f, 50f, cx + 6f, 50f, InkColor, 1.4f)
            arc(cx - 5f, 52f, 10f, 8f, 20f, 140f, Color(0xC89A7FA8), 1.2f)
        }
    }
    if (isFemale) {
        line(34.5f, 47f, 31.5f, 44.5f, InkColor, 1.2f)
        line(65.5f, 47f, 68.5f, 44.5f, InkColor, 1.2f)
    }

    // eyebrows
    when (stage) {
        0 -> {
            line(34f, 41f, 45f, 42.5f, hair, 1.6f)
            line(55f, 42.5f, 66f, 41f, hair, 1.6f)
        }
        4 -> {
            line(34f, 42f, 45f, 39f, hair, 1.8f)
            line(55f, 39f, 66f, 42f, hair, 1.8f)
        }
        else -> {
            line(34f, 41f, 45f, 40f, hair, 1.6f)
            line(55f, 40f, 66f, 41f, hair, 1.6f)
        }
    }

    // cheeks and mouth
    oval(31f, 57f, 8f, 5f, Color(0x5AFF6B81))
    oval(61f, 57f, 8f, 5f, Color(0x5AFF6B81))
    when (stage) {
        0 -> oval(47f, 60f, 6f, 6f, MouthColor)
        1 -> arc(45f, 56f, 10f, 8f, 20f, 140f, MouthColor, 1.4f)
        else -> arc(43f, 55f, 14f, 11f, 20f, 140f, MouthColor, 1.6f)
    }

    // glasses for the later stages
    if (stage >= 3) {
        val frame = Color(0xFF37474F)
        for (cx in eyeCenters) {
            drawCircle(
                color = frame,
                radius = 8.5f * u,
                center = p(cx, 50f),
                style = Stroke(width = 1.5f * u)
            )
        }
        line(48.5f, 50f, 51.5f, 50f, frame, 1.5f)
        line(31.5f, 50f, 28f, 49f, frame, 1.2f)
        line(68.5f, 50f, 72f, 49f, frame, 1.2f)
    }
}
