package by.physico.app.ui

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshots.SnapshotStateList
import by.physico.app.data.AppState
import by.physico.app.data.Engine
import by.physico.app.data.ErrorKind
import by.physico.app.data.Formula
import by.physico.app.data.Gender
import by.physico.app.data.Lesson
import by.physico.app.data.PhysicsCatalog
import by.physico.app.data.ProgressStore
import by.physico.app.data.Question
import by.physico.app.data.Rules
import by.physico.app.data.SessionKind
import by.physico.app.data.Topic

enum class MainTab(val title: String, val emoji: String) {
    LEARN("Учёба", "📚"),
    QUICK("В пути", "🚌"),
    REVIEW("Повторение", "🔁"),
    EXAM("Экзамен", "📝"),
    PROFILE("Профиль", "🧑‍🎓")
}

data class QuizSetup(
    val id: Long,
    val kind: SessionKind,
    val title: String,
    val questions: List<Question>,
    val timeLimitSec: Int,
    val instantFeedback: Boolean
)

data class CardsSetup(
    val id: Long,
    val title: String,
    val cards: List<Formula>
)

data class QuizResult(
    val correct: Int,
    val total: Int,
    val wrong: List<Question>,
    val timeSpentSec: Int
)

data class SessionSummary(
    val title: String,
    val kind: SessionKind,
    val correct: Int,
    val total: Int,
    val xpGained: Int,
    val wrong: List<Question>,
    val timeSec: Int
)

sealed interface Screen {
    data class OpenLesson(val lessonId: String) : Screen
    data class Quiz(val setup: QuizSetup) : Screen
    data class Cards(val setup: CardsSetup) : Screen
    data class Result(val summary: SessionSummary) : Screen
    data object FormulaBook : Screen
}

data class GameEvent(val id: Long, val text: String)

class AppController(private val store: ProgressStore) {

    var state: AppState by mutableStateOf(Engine.normalize(store.load(), Rules.today()))
        private set

    var tab: MainTab by mutableStateOf(MainTab.LEARN)
    var screen: Screen? by mutableStateOf<Screen?>(null)

    val events: SnapshotStateList<GameEvent> = mutableStateListOf()

    private var eventCounter = 0L
    private var sessionCounter = 0L

    // ------------------------------------------------------------ state changes

    /** Applies a change, runs bonuses and returns the XP gained. */
    private fun mutate(transform: (AppState) -> AppState): Int {
        val old = Engine.normalize(state, Rules.today())
        val changed = transform(old)
        val settled = Engine.settle(old, changed)
        state = settled.first
        store.save(settled.first)
        for (message in settled.second) {
            toast(message)
        }
        return settled.first.totalXp - old.totalXp
    }

    fun toast(text: String) {
        eventCounter += 1
        events.add(GameEvent(eventCounter, text))
    }

    fun dismissEvent() {
        if (events.isNotEmpty()) events.removeAt(0)
    }

    fun chooseCharacter(gender: Gender) {
        mutate { it.copy(onboarded = true, gender = gender) }
    }

    fun changeGender(gender: Gender) {
        mutate { it.copy(gender = gender) }
    }

    fun recordAnswer(question: Question, correct: Boolean, kind: SessionKind?) {
        val today = Rules.today()
        val xp = kind?.xpPerCorrect ?: 0
        val review = kind?.countsAsReview ?: false
        mutate { Engine.answer(it, question, correct, xp, review, today) }
    }

    fun recordErrorKind(kind: ErrorKind) {
        mutate { Engine.errorKind(it, kind) }
    }

    fun toggleFavorite(formulaId: String) {
        mutate {
            val favorites = if (it.favoriteFormulaIds.contains(formulaId)) {
                it.favoriteFormulaIds - formulaId
            } else {
                it.favoriteFormulaIds + formulaId
            }
            it.copy(favoriteFormulaIds = favorites)
        }
    }

    fun cardAnswer(formulaId: String, known: Boolean) {
        val today = Rules.today()
        mutate { Engine.cardAnswer(it, formulaId, known, today) }
    }

    fun completeLesson(lesson: Lesson, practiceCorrect: Int, testCorrect: Int, testPercent: Int) {
        val today = Rules.today()
        val gained = mutate { s ->
            val first = !s.completedLessonIds.contains(lesson.id)
            var st = Engine.touch(s, today)
            if (first) {
                st = Engine.addXp(st, (practiceCorrect + testCorrect) * 10 + 20)
            }
            val best = maxOf(testPercent, st.bestTestPercent[lesson.id] ?: 0)
            st = st.copy(
                completedLessonIds = st.completedLessonIds + lesson.id,
                bestTestPercent = st.bestTestPercent + (lesson.id to best),
                perfectTests = st.perfectTests + (if (testPercent == 100) 1 else 0),
                lastLessonId = lesson.id
            )
            Engine.scheduleLesson(st, lesson, today)
        }
        screen = null
        tab = MainTab.LEARN
        if (gained > 0) {
            toast("✅ Урок пройден! +$gained XP")
        } else {
            toast("✅ Урок повторён")
        }
    }

    fun finishSession(setup: QuizSetup, result: QuizResult) {
        val today = Rules.today()
        val percent = if (result.total == 0) 0 else result.correct * 100 / result.total
        var bonus = 0
        if (setup.kind == SessionKind.EXAM) {
            bonus = result.correct * 5 + (if (percent >= 60) 20 else 0)
        }
        mutate { s ->
            var st = Engine.touch(s, today)
            if (bonus > 0) st = Engine.addXp(st, bonus)
            if (setup.kind == SessionKind.QUICK || setup.kind == SessionKind.MINI_TEST) {
                st = st.copy(quickSessions = st.quickSessions + 1)
            }
            if (setup.kind == SessionKind.EXAM) {
                st = st.copy(
                    examsDone = st.examsDone + 1,
                    bestExamPercent = maxOf(st.bestExamPercent, percent)
                )
            }
            st
        }
        val xpShown = result.correct * setup.kind.xpPerCorrect + bonus
        screen = Screen.Result(
            SessionSummary(
                title = setup.title,
                kind = setup.kind,
                correct = result.correct,
                total = result.total,
                xpGained = xpShown,
                wrong = result.wrong,
                timeSec = result.timeSpentSec
            )
        )
    }

    fun resetAll() {
        store.clear()
        state = Engine.normalize(AppState(), Rules.today())
        tab = MainTab.LEARN
        screen = null
        events.clear()
    }

    // ------------------------------------------------------------ navigation

    fun closeScreen() {
        screen = null
    }

    fun openFormulaBook() {
        screen = Screen.FormulaBook
    }

    fun isUnlocked(topic: Topic, index: Int): Boolean =
        index == 0 || state.completedLessonIds.contains(topic.lessons[index - 1].id)

    fun openLesson(topic: Topic, index: Int) {
        if (isUnlocked(topic, index)) {
            screen = Screen.OpenLesson(topic.lessons[index].id)
        } else {
            val previous = topic.lessons[index - 1]
            toast("🔒 Сначала пройди урок «" + previous.title + "»")
        }
    }

    fun openLessonById(lessonId: String) {
        screen = Screen.OpenLesson(lessonId)
    }

    fun nextLesson(): Lesson? {
        val topics = PhysicsCatalog.subject.topics
        val lastTopic = PhysicsCatalog.topicOfLesson[state.lastLessonId]
        val ordered = if (lastTopic != null) {
            listOf(lastTopic) + topics.filter { it.id != lastTopic.id }
        } else {
            topics
        }
        for (topic in ordered) {
            for (i in topic.lessons.indices) {
                val lesson = topic.lessons[i]
                if (!state.completedLessonIds.contains(lesson.id) && isUnlocked(topic, i)) return lesson
            }
        }
        return null
    }

    // ------------------------------------------------------------ sessions

    private fun studyPool(): List<Question> {
        val done = PhysicsCatalog.allLessons.filter { state.completedLessonIds.contains(it.id) }
        val source = if (done.isEmpty()) PhysicsCatalog.allLessons else done
        return source.flatMap { it.practice + it.test }
    }

    private fun formulaPool(): List<Formula> {
        val done = PhysicsCatalog.allLessons.filter { state.completedLessonIds.contains(it.id) }
        val source = if (done.isEmpty()) PhysicsCatalog.allLessons else done
        return source.flatMap { it.formulas }
    }

    private fun openQuiz(
        kind: SessionKind,
        title: String,
        questions: List<Question>,
        timeLimitSec: Int,
        instant: Boolean
    ) {
        if (questions.isEmpty()) {
            toast("Пока нет заданий для этого режима")
            return
        }
        sessionCounter += 1
        screen = Screen.Quiz(QuizSetup(sessionCounter, kind, title, questions, timeLimitSec, instant))
    }

    private fun openCards(title: String, cards: List<Formula>) {
        if (cards.isEmpty()) {
            toast("Пока нет карточек для этого режима")
            return
        }
        sessionCounter += 1
        screen = Screen.Cards(CardsSetup(sessionCounter, title, cards))
    }

    fun startQuick() {
        openQuiz(SessionKind.QUICK, "Быстрые вопросы", studyPool().shuffled().take(5), 0, true)
    }

    fun startMiniTest() {
        openQuiz(SessionKind.MINI_TEST, "Мини-тест", studyPool().shuffled().take(8), 300, false)
    }

    fun startReview() {
        val questions = Engine.dueQuestions(state, Rules.today()).take(10)
        openQuiz(SessionKind.REVIEW, "Повторение", questions, 0, true)
    }

    fun startMistakes() {
        val questions = Engine.mistakeQuestions(state).shuffled().take(10)
        openQuiz(SessionKind.MISTAKES, "Работа над ошибками", questions, 0, true)
    }

    fun retryWrong(wrong: List<Question>) {
        openQuiz(SessionKind.MISTAKES, "Разбор ошибок", wrong.shuffled(), 0, true)
    }

    fun startTopicTest(topic: Topic) {
        val questions = topic.lessons.flatMap { it.practice + it.test }.shuffled().take(10)
        openQuiz(SessionKind.TOPIC_TEST, "Тест: " + topic.title, questions, 0, false)
    }

    fun startMixed() {
        openQuiz(SessionKind.MIXED, "Смешанный тест", PhysicsCatalog.allQuestions.shuffled().take(10), 0, false)
    }

    fun startExam() {
        val count = minOf(20, PhysicsCatalog.allQuestions.size)
        val questions = PhysicsCatalog.allQuestions.shuffled().take(count)
        openQuiz(SessionKind.EXAM, "Пробный экзамен", questions, count * 90, false)
    }

    fun startFormulaCards() {
        val due = Engine.dueFormulas(state, Rules.today())
        val extra = formulaPool().filter { f -> due.none { it.id == f.id } }.shuffled()
        openCards("Карточки формул", (due + extra).take(8))
    }

    fun startDueCards() {
        openCards("Карточки к повторению", Engine.dueFormulas(state, Rules.today()).take(12))
    }

    fun startFavoriteCards() {
        val cards = state.favoriteFormulaIds.mapNotNull { PhysicsCatalog.formulaById[it] }.shuffled()
        openCards("Избранные формулы", cards)
    }
}
