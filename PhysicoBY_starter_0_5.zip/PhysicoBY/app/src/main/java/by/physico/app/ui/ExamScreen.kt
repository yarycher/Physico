package by.physico.app.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.width
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import by.physico.app.data.PhysicsCatalog

@Composable
fun ExamScreen(controller: AppController, modifier: Modifier = Modifier) {
    val s = controller.state
    val cs = MaterialTheme.colorScheme
    val examCount = minOf(20, PhysicsCatalog.allQuestions.size)
    val examMinutes = examCount * 90 / 60

    PageList(modifier) {
        item {
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(text = "Экзамен 📝", style = MaterialTheme.typography.headlineMedium)
                Text(
                    text = "Проверь себя без подсказок: разбор ошибок откроется после теста.",
                    style = MaterialTheme.typography.bodyLarge,
                    color = cs.onSurfaceVariant
                )
            }
        }

        item {
            AppCard(containerColor = cs.primaryContainer, borderColor = cs.primary) {
                Text(
                    text = "Пробный экзамен",
                    style = MaterialTheme.typography.labelLarge,
                    color = cs.onPrimaryContainer
                )
                Text(
                    text = examCount.toString() + " заданий · " + examMinutes.toString() + " минут",
                    style = MaterialTheme.typography.headlineSmall,
                    color = cs.onPrimaryContainer
                )
                Spacer(Modifier.height(4.dp))
                Text(
                    text = "Вопросы по всему курсу в случайном порядке, на время и без подсказок. Тренировочный вариант, не официальный.",
                    color = cs.onPrimaryContainer
                )
                Spacer(Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Pill(text = "Попыток: " + s.examsDone.toString())
                    Pill(text = "Лучший результат: " + s.bestExamPercent.toString() + "%")
                }
                Spacer(Modifier.height(14.dp))
                PrimaryButton(text = "Начать пробный экзамен", onClick = { controller.startExam() })
            }
        }

        item {
            AppCard {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(text = "🎲", fontSize = 32.sp)
                    Spacer(Modifier.width(14.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(text = "Смешанный тест", style = MaterialTheme.typography.titleMedium)
                        Text(
                            text = "10 случайных вопросов без ограничения по времени",
                            style = MaterialTheme.typography.bodySmall,
                            color = cs.onSurfaceVariant
                        )
                    }
                }
                Spacer(Modifier.height(12.dp))
                SecondaryButton(text = "Начать смешанный тест", onClick = { controller.startMixed() })
            }
        }

        item { SectionTitle("Тематические тесты") }

        for (topic in PhysicsCatalog.subject.topics) {
            item {
                val count = topic.lessons.sumOf { it.practice.size + it.test.size }
                AppCard(onClick = { controller.startTopicTest(topic) }) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(text = topic.emoji, fontSize = 30.sp)
                        Spacer(Modifier.width(14.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(text = topic.title, style = MaterialTheme.typography.titleMedium)
                            Text(
                                text = "До 10 вопросов из " + count.toString() + " в теме",
                                style = MaterialTheme.typography.bodySmall,
                                color = cs.onSurfaceVariant
                            )
                        }
                        Pill(
                            text = "Начать",
                            container = cs.secondaryContainer,
                            content = cs.onSecondaryContainer
                        )
                    }
                }
            }
        }

        item {
            Text(
                text = "Задания авторские и тренировочные. Для подготовки к ЦЭ и ЦТ ориентируйся также на официальные материалы РИКЗ.",
                style = MaterialTheme.typography.bodySmall,
                color = cs.onSurfaceVariant
            )
        }
    }
}
