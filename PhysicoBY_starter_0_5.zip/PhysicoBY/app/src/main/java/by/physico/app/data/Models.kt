package by.physico.app.data

data class Question(
    val id: String,
    val prompt: String,
    val options: List<String>,
    val correctOptionIndex: Int,
    val explanation: String
)

data class Formula(
    val id: String,
    val title: String,
    val expression: String,
    val legend: String
)

data class WorkedExample(
    val task: String,
    val steps: List<String>,
    val answer: String
)

data class Lesson(
    val id: String,
    val title: String,
    val summary: String,
    val estimatedMinutes: Int,
    val theory: List<String>,
    val formulas: List<Formula>,
    val examples: List<WorkedExample>,
    /** Guided practice inside the lesson. */
    val practice: List<Question>,
    /** Mandatory end-of-lesson assessment: the lesson counts only after it is passed. */
    val test: List<Question>,
    val passingPercent: Int = 60
)

data class Topic(
    val id: String,
    val title: String,
    val description: String,
    val emoji: String,
    val lessons: List<Lesson>
)

data class Subject(
    val id: String,
    val title: String,
    val description: String,
    val topics: List<Topic>
)

enum class Gender(val label: String) {
    MALE("Парень"),
    FEMALE("Девушка")
}

enum class ErrorKind(val label: String) {
    UNKNOWN_FORMULA("Не знал формулу"),
    WRONG_FORMULA("Выбрал не ту формулу"),
    CALCULATION("Ошибся в вычислениях"),
    MEANING("Не понял смысл")
}

enum class CharacterStage(val title: String, val minGrowth: Int, val tagline: String, val emoji: String) {
    SLACKER("Раздолбай", 0, "Сонный и растрёпанный. Физика пока подождёт.", "💤"),
    NOVICE("Новичок", 10, "Проснулся и открыл учебник.", "📓"),
    STUDENT("Ученик", 40, "Собран, внимателен и решает задачи.", "✏️"),
    EXPERT("Знаток", 90, "Уверенно держит формулы в голове.", "💡"),
    PRO("Профи", 150, "Настоящий физик-исследователь.", "⚛️");

    fun next(): CharacterStage? = CharacterStage.entries.getOrNull(ordinal + 1)

    companion object {
        fun forGrowth(points: Int): CharacterStage =
            CharacterStage.entries.last { points >= it.minGrowth }
    }
}

enum class SessionKind(val xpPerCorrect: Int, val countsAsReview: Boolean) {
    QUICK(3, false),
    MINI_TEST(4, false),
    REVIEW(5, true),
    MISTAKES(5, true),
    TOPIC_TEST(5, false),
    MIXED(5, false),
    EXAM(0, false)
}

/** One scheduled repetition. Keys of formula cards start with [Rules.FORMULA_PREFIX]. */
data class ReviewItem(
    val key: String,
    val box: Int,
    val dueDay: Long
)

data class AppState(
    val onboarded: Boolean = false,
    val gender: Gender = Gender.MALE,
    val totalXp: Int = 0,
    val completedLessonIds: Set<String> = emptySet(),
    val bestTestPercent: Map<String, Int> = emptyMap(),
    val correctAnswers: Int = 0,
    val totalAnswers: Int = 0,
    val reviewItems: Map<String, ReviewItem> = emptyMap(),
    val masteredCount: Int = 0,
    val errorKindCounts: Map<String, Int> = emptyMap(),
    val favoriteFormulaIds: Set<String> = emptySet(),
    val streak: Int = 0,
    val bestStreak: Int = 0,
    val lastActiveDay: Long = -1L,
    val dayKey: Long = -1L,
    val xpToday: Int = 0,
    val correctToday: Int = 0,
    val reviewedToday: Int = 0,
    val bonusDay: Long = -1L,
    val dailyBonusCount: Int = 0,
    val unlockedAchievements: Set<String> = emptySet(),
    val perfectTests: Int = 0,
    val quickSessions: Int = 0,
    val examsDone: Int = 0,
    val bestExamPercent: Int = 0,
    val lastLessonId: String = ""
)
