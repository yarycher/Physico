package by.physico.app.data

import java.time.LocalDate
import kotlin.math.sqrt

object Rules {
    /** Spaced repetition: immediately, after 1, 3, 7 and 14 days. */
    val INTERVAL_DAYS: IntArray = intArrayOf(0, 1, 3, 7, 14)

    const val DAILY_XP_GOAL = 30
    const val DAILY_CORRECT_GOAL = 10
    const val DAILY_REVIEW_GOAL = 5
    const val DAILY_BONUS_XP = 25
    const val FORMULA_PREFIX = "f:"

    fun today(): Long = LocalDate.now().toEpochDay()

    fun levelOf(xp: Int): Int = sqrt(xp / 50.0).toInt() + 1
    fun levelStartXp(level: Int): Int = 50 * (level - 1) * (level - 1)
    fun levelEndXp(level: Int): Int = 50 * level * level

    /** Growth points drive the character; they are independent from XP and level. */
    fun growthPoints(s: AppState): Int =
        s.completedLessonIds.size * 10 + s.examsDone * 5 + s.dailyBonusCount * 3 + s.masteredCount

    fun stageOf(s: AppState): CharacterStage = CharacterStage.forGrowth(growthPoints(s))

    fun effectiveStreak(s: AppState, today: Long): Int =
        if (s.lastActiveDay >= today - 1) s.streak else 0
}

data class DailyTask(val emoji: String, val title: String, val current: Int, val goal: Int) {
    val done: Boolean get() = current >= goal
    val fraction: Float get() = if (goal <= 0) 1f else (current.toFloat() / goal).coerceIn(0f, 1f)
}

data class Achievement(
    val id: String,
    val emoji: String,
    val title: String,
    val description: String,
    val target: Int,
    val current: (AppState) -> Int
)

object Achievements {
    val all: List<Achievement> = listOf(
        Achievement("first-lesson", "🎯", "Первый шаг", "Пройди первый урок", 1) { it.completedLessonIds.size },
        Achievement("lessons-5", "📚", "Прилежный ученик", "Пройди 5 уроков", 5) { it.completedLessonIds.size },
        Achievement("lessons-all", "🏆", "Курс пройден", "Пройди все уроки", PhysicsCatalog.allLessons.size) { it.completedLessonIds.size },
        Achievement("streak-3", "🔥", "Три дня подряд", "Занимайся 3 дня подряд", 3) { it.bestStreak },
        Achievement("streak-7", "🔥", "Неделя без пропусков", "Занимайся 7 дней подряд", 7) { it.bestStreak },
        Achievement("xp-100", "⭐", "Сто очков опыта", "Набери 100 XP", 100) { it.totalXp },
        Achievement("xp-500", "🌟", "Пятьсот очков опыта", "Набери 500 XP", 500) { it.totalXp },
        Achievement("xp-1000", "💫", "Тысяча очков опыта", "Набери 1000 XP", 1000) { it.totalXp },
        Achievement("correct-50", "🎓", "Меткий глаз", "Ответь верно на 50 вопросов", 50) { it.correctAnswers },
        Achievement("correct-200", "🧠", "Мастер ответов", "Ответь верно на 200 вопросов", 200) { it.correctAnswers },
        Achievement("perfect-test", "💯", "Идеальный тест", "Пройди итоговый тест урока без ошибок", 1) { it.perfectTests },
        Achievement("fixer", "🛠️", "Работа над ошибками", "Полностью закрепи 10 заданий в повторении", 10) { it.masteredCount },
        Achievement("quick-5", "🚌", "Всегда в пути", "Проведи 5 коротких занятий", 5) { it.quickSessions },
        Achievement("exam-1", "📝", "Пробный экзамен", "Сдай пробный экзамен", 1) { it.examsDone },
        Achievement("exam-80", "🥇", "Экзамен на 80%", "Набери 80% на пробном экзамене", 80) { it.bestExamPercent },
        Achievement("daily-3", "📅", "Дисциплина", "Выполни все ежедневные задания 3 раза", 3) { it.dailyBonusCount },
        Achievement("formulas-5", "⭐", "Коллекционер формул", "Добавь 5 формул в избранное", 5) { it.favoriteFormulaIds.size }
    )
}

object Engine {

    fun normalize(s: AppState, today: Long): AppState =
        if (s.dayKey == today) s
        else s.copy(dayKey = today, xpToday = 0, correctToday = 0, reviewedToday = 0)

    fun touch(s: AppState, today: Long): AppState {
        if (s.lastActiveDay == today) return s
        val newStreak = if (s.lastActiveDay == today - 1) s.streak + 1 else 1
        return s.copy(
            streak = newStreak,
            bestStreak = maxOf(s.bestStreak, newStreak),
            lastActiveDay = today
        )
    }

    fun addXp(s: AppState, amount: Int): AppState =
        s.copy(totalXp = s.totalXp + amount, xpToday = s.xpToday + amount)

    fun isFormulaKey(key: String): Boolean = key.startsWith(Rules.FORMULA_PREFIX)

    /** Records one answer: statistics, streak, XP and the spaced-repetition schedule. */
    fun answer(
        s0: AppState,
        q: Question,
        correct: Boolean,
        xpOnCorrect: Int,
        countsAsReview: Boolean,
        today: Long
    ): AppState {
        var s = touch(normalize(s0, today), today)
        s = s.copy(
            correctAnswers = s.correctAnswers + (if (correct) 1 else 0),
            totalAnswers = s.totalAnswers + 1,
            correctToday = s.correctToday + (if (correct) 1 else 0),
            reviewedToday = s.reviewedToday + (if (countsAsReview) 1 else 0)
        )
        val items = s.reviewItems.toMutableMap()
        var mastered = s.masteredCount
        if (!correct) {
            // A mistake sends the material back to the earliest repetition.
            items[q.id] = ReviewItem(q.id, 0, today)
        } else {
            val item = items[q.id]
            if (item != null && item.dueDay <= today) {
                val nextBox = item.box + 1
                if (nextBox >= Rules.INTERVAL_DAYS.size) {
                    items.remove(q.id)
                    mastered += 1
                } else {
                    items[q.id] = ReviewItem(q.id, nextBox, today + Rules.INTERVAL_DAYS[nextBox])
                }
            }
        }
        s = s.copy(reviewItems = items, masteredCount = mastered)
        if (correct && xpOnCorrect > 0) s = addXp(s, xpOnCorrect)
        return s
    }

    fun errorKind(s: AppState, kind: ErrorKind): AppState {
        val old = s.errorKindCounts[kind.name] ?: 0
        return s.copy(errorKindCounts = s.errorKindCounts + (kind.name to old + 1))
    }

    fun cardAnswer(s0: AppState, formulaId: String, known: Boolean, today: Long): AppState {
        var s = touch(normalize(s0, today), today)
        val key = Rules.FORMULA_PREFIX + formulaId
        val item = s.reviewItems[key]
        val items = s.reviewItems.toMutableMap()
        var mastered = s.masteredCount
        if (!known) {
            items[key] = ReviewItem(key, 0, today)
        } else if (item == null) {
            items[key] = ReviewItem(key, 1, today + Rules.INTERVAL_DAYS[1])
        } else if (item.dueDay <= today) {
            val nextBox = item.box + 1
            if (nextBox >= Rules.INTERVAL_DAYS.size) {
                items.remove(key)
                mastered += 1
            } else {
                items[key] = ReviewItem(key, nextBox, today + Rules.INTERVAL_DAYS[nextBox])
            }
        }
        s = s.copy(
            reviewItems = items,
            masteredCount = mastered,
            reviewedToday = s.reviewedToday + 1
        )
        if (known) s = addXp(s, 2)
        return s
    }

    /** After a lesson is passed, its material is scheduled for repetition after one day. */
    fun scheduleLesson(s: AppState, lesson: Lesson, today: Long): AppState {
        val items = s.reviewItems.toMutableMap()
        for (q in lesson.practice + lesson.test) {
            if (!items.containsKey(q.id)) {
                items[q.id] = ReviewItem(q.id, 1, today + Rules.INTERVAL_DAYS[1])
            }
        }
        for (f in lesson.formulas) {
            val key = Rules.FORMULA_PREFIX + f.id
            if (!items.containsKey(key)) {
                items[key] = ReviewItem(key, 1, today + Rules.INTERVAL_DAYS[1])
            }
        }
        return s.copy(reviewItems = items)
    }

    fun dueItems(s: AppState, today: Long): List<ReviewItem> =
        s.reviewItems.values
            .filter { it.dueDay <= today }
            .sortedWith(compareBy<ReviewItem>({ it.box }, { it.dueDay }))

    fun dueQuestions(s: AppState, today: Long): List<Question> =
        dueItems(s, today)
            .filter { !isFormulaKey(it.key) }
            .mapNotNull { PhysicsCatalog.questionById[it.key] }

    fun dueFormulas(s: AppState, today: Long): List<Formula> =
        dueItems(s, today)
            .filter { isFormulaKey(it.key) }
            .mapNotNull { PhysicsCatalog.formulaById[it.key.removePrefix(Rules.FORMULA_PREFIX)] }

    fun mistakeQuestions(s: AppState): List<Question> =
        s.reviewItems.values
            .filter { it.box == 0 && !isFormulaKey(it.key) }
            .mapNotNull { PhysicsCatalog.questionById[it.key] }

    fun dailyTasks(s: AppState): List<DailyTask> = listOf(
        DailyTask("⭐", "Набери ${Rules.DAILY_XP_GOAL} XP", s.xpToday, Rules.DAILY_XP_GOAL),
        DailyTask("✅", "Ответь верно на ${Rules.DAILY_CORRECT_GOAL} вопросов", s.correctToday, Rules.DAILY_CORRECT_GOAL),
        DailyTask("🔁", "Повтори ${Rules.DAILY_REVIEW_GOAL} заданий или карточек", s.reviewedToday, Rules.DAILY_REVIEW_GOAL)
    )

    /** Applies bonuses that depend on the new state and produces messages for the player. */
    fun settle(old: AppState, changed: AppState): Pair<AppState, List<String>> {
        var st = changed
        val messages = mutableListOf<String>()

        val tasks = dailyTasks(st)
        if (tasks.all { it.done } && st.bonusDay != st.dayKey) {
            st = addXp(st, Rules.DAILY_BONUS_XP)
            st = st.copy(bonusDay = st.dayKey, dailyBonusCount = st.dailyBonusCount + 1)
            messages.add("🎉 Все ежедневные задания выполнены! +${Rules.DAILY_BONUS_XP} XP")
        }

        val oldLevel = Rules.levelOf(old.totalXp)
        val newLevel = Rules.levelOf(st.totalXp)
        if (newLevel > oldLevel) {
            messages.add("⬆️ Новый уровень: $newLevel")
        }

        val oldStage = Rules.stageOf(old)
        val newStage = Rules.stageOf(st)
        if (newStage != oldStage) {
            messages.add("✨ Персонаж вырос: ${newStage.title}!")
        }

        val unlocked = Achievements.all.filter {
            !st.unlockedAchievements.contains(it.id) && it.current(st) >= it.target
        }
        if (unlocked.isNotEmpty()) {
            st = st.copy(unlockedAchievements = st.unlockedAchievements + unlocked.map { it.id })
            for (a in unlocked) {
                messages.add("${a.emoji} Достижение: ${a.title}")
            }
        }
        return Pair(st, messages)
    }
}
