package by.physico.app.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import by.physico.app.data.Formula
import by.physico.app.data.PhysicsCatalog
import by.physico.app.ui.theme.PhysicoColors

@Composable
fun FormulaBookScreen(controller: AppController) {
    val cs = MaterialTheme.colorScheme
    var onlyFavorites by remember { mutableStateOf(false) }
    val favorites = controller.state.favoriteFormulaIds

    BackHandler { controller.closeScreen() }

    PageList {
        item { ScreenHeader(title = "Справочник формул", onBack = { controller.closeScreen() }) }
        item {
            Row(modifier = Modifier.padding(bottom = 2.dp)) {
                ChoiceChip(
                    text = "Все формулы",
                    selected = !onlyFavorites,
                    onClick = { onlyFavorites = false }
                )
                Spacer(Modifier.width(8.dp))
                ChoiceChip(
                    text = "⭐ Избранное (" + favorites.size.toString() + ")",
                    selected = onlyFavorites,
                    onClick = { onlyFavorites = true }
                )
            }
        }
        for (topic in PhysicsCatalog.subject.topics) {
            val formulas = topic.lessons.flatMap { it.formulas }.filter { !onlyFavorites || favorites.contains(it.id) }
            if (formulas.isNotEmpty()) {
                item { SectionTitle(topic.emoji + " " + topic.title) }
                items(formulas.size) { i ->
                    FormulaItem(
                        formula = formulas[i],
                        isFavorite = favorites.contains(formulas[i].id),
                        onToggle = { controller.toggleFavorite(formulas[i].id) }
                    )
                }
            }
        }
        if (onlyFavorites && favorites.isEmpty()) {
            item {
                Text(
                    text = "Пока пусто. Нажми на звёздочку у формулы, чтобы добавить её в избранное.",
                    color = cs.onSurfaceVariant
                )
            }
        }
    }
}

@Composable
private fun FormulaItem(formula: Formula, isFavorite: Boolean, onToggle: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    AppCard {
        Row(verticalAlignment = Alignment.Top) {
            Column(modifier = Modifier.weight(1f)) {
                Text(text = formula.title, style = MaterialTheme.typography.titleSmall, color = cs.onSurfaceVariant)
                Spacer(Modifier.height(6.dp))
                Text(text = formula.expression, style = MaterialTheme.typography.headlineSmall, color = cs.primary)
                Spacer(Modifier.height(6.dp))
                Text(text = formula.legend, style = MaterialTheme.typography.bodyMedium)
            }
            ChoiceChip(
                text = if (isFavorite) "⭐" else "☆",
                selected = isFavorite,
                onClick = onToggle
            )
        }
    }
}
