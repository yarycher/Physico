package by.physico.app.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.width
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
private fun QuickCard(
    emoji: String,
    title: String,
    subtitle: String,
    duration: String,
    enabled: Boolean,
    onClick: () -> Unit
) {
    val cs = MaterialTheme.colorScheme
    AppCard(onClick = if (enabled) onClick else null) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(text = emoji, fontSize = 34.sp)
            Spacer(Modifier.width(14.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleMedium,
                    color = if (enabled) cs.onSurface else cs.outline
                )
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.bodySmall,
                    color = cs.onSurfaceVariant
                )
            }
            Pill(text = duration, container = cs.secondaryContainer, content = cs.onSecondaryContainer)
        }
    }
}

@Composable
fun QuickScreen(controller: AppController, modifier: Modifier = Modifier) {
    val s = controller.state
    val cs = MaterialTheme.colorScheme
    val favoritesCount = s.favoriteFormulaIds.size
    val next = controller.nextLesson()

    PageList(modifier) {
        item {
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(text = "В пути 🚌", style = MaterialTheme.typography.headlineMedium)
                Text(
                    text = "Короткие занятия на 1–5 минут. Всё работает без интернета.",
                    style = MaterialTheme.typography.bodyLarge,
                    color = cs.onSurfaceVariant
                )
            }
        }
        item {
            QuickCard(
                emoji = "🃏",
                title = "Карточки формул",
                subtitle = "8 карточек: сначала те, которые пора повторить",
                duration = "2 мин",
                enabled = true,
                onClick = { controller.startFormulaCards() }
            )
        }
        item {
            QuickCard(
                emoji = "⚡",
                title = "Быстрые вопросы",
                subtitle = "5 вопросов с мгновенным разбором ответа",
                duration = "2 мин",
                enabled = true,
                onClick = { controller.startQuick() }
            )
        }
        item {
            QuickCard(
                emoji = "⏱",
                title = "Мини-тест",
                subtitle = "8 вопросов на время, результат в конце",
                duration = "5 мин",
                enabled = true,
                onClick = { controller.startMiniTest() }
            )
        }
        item {
            QuickCard(
                emoji = "⭐",
                title = "Избранные формулы",
                subtitle = if (favoritesCount > 0) "Твои отмеченные формулы: " + favoritesCount.toString()
                else "Отмечай звёздочкой формулы в справочнике или на карточках",
                duration = "1 мин",
                enabled = favoritesCount > 0,
                onClick = { controller.startFavoriteCards() }
            )
        }
        item {
            QuickCard(
                emoji = "📖",
                title = "Справочник формул",
                subtitle = "Все формулы курса с расшифровкой обозначений",
                duration = "поиск",
                enabled = true,
                onClick = { controller.openFormulaBook() }
            )
        }
        if (next != null && s.lastLessonId.isNotEmpty()) {
            item {
                AppCard(
                    containerColor = cs.primaryContainer,
                    borderColor = cs.primary,
                    onClick = { controller.openLessonById(next.id) }
                ) {
                    Text(
                        text = "Есть время на полный урок?",
                        style = MaterialTheme.typography.labelLarge,
                        color = cs.onPrimaryContainer
                    )
                    Spacer(Modifier.height(4.dp))
                    Text(
                        text = "Продолжить: " + next.title,
                        style = MaterialTheme.typography.titleMedium,
                        color = cs.onPrimaryContainer
                    )
                }
            }
        }
        item {
            Text(
                text = "Вопросы берутся из пройденных уроков. Если ты ещё ничего не прошёл, из всего курса.",
                style = MaterialTheme.typography.bodySmall,
                color = cs.onSurfaceVariant
            )
        }
    }
}
