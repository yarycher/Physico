package by.physico.app.data

import android.content.Context

/** Local, offline progress storage (SharedPreferences). */
class ProgressStore(context: Context) {
    private val app = context.applicationContext
    private val prefs = app.getSharedPreferences("physico_state_v5", Context.MODE_PRIVATE)

    fun load(): AppState {
        if (!prefs.contains(K_SAVED)) return migrateLegacy()
        return AppState(
            onboarded = prefs.getBoolean("onboarded", false),
            gender = parseGender(prefs.getString("gender", null)),
            totalXp = prefs.getInt("xp", 0),
            completedLessonIds = decodeSet(prefs.getString("completed", null)),
            bestTestPercent = decodeIntMap(prefs.getString("best_test", null)),
            correctAnswers = prefs.getInt("correct", 0),
            totalAnswers = prefs.getInt("total", 0),
            reviewItems = decodeItems(prefs.getString("review", null)),
            masteredCount = prefs.getInt("mastered", 0),
            errorKindCounts = decodeIntMap(prefs.getString("error_kinds", null)),
            favoriteFormulaIds = decodeSet(prefs.getString("favorites", null)),
            streak = prefs.getInt("streak", 0),
            bestStreak = prefs.getInt("best_streak", 0),
            lastActiveDay = prefs.getLong("last_active", -1L),
            dayKey = prefs.getLong("day_key", -1L),
            xpToday = prefs.getInt("xp_today", 0),
            correctToday = prefs.getInt("correct_today", 0),
            reviewedToday = prefs.getInt("reviewed_today", 0),
            bonusDay = prefs.getLong("bonus_day", -1L),
            dailyBonusCount = prefs.getInt("daily_bonus_count", 0),
            unlockedAchievements = decodeSet(prefs.getString("achievements", null)),
            perfectTests = prefs.getInt("perfect_tests", 0),
            quickSessions = prefs.getInt("quick_sessions", 0),
            examsDone = prefs.getInt("exams_done", 0),
            bestExamPercent = prefs.getInt("best_exam", 0),
            lastLessonId = prefs.getString("last_lesson", "") ?: ""
        )
    }

    fun save(s: AppState) {
        prefs.edit()
            .putBoolean(K_SAVED, true)
            .putBoolean("onboarded", s.onboarded)
            .putString("gender", s.gender.name)
            .putInt("xp", s.totalXp)
            .putString("completed", encodeSet(s.completedLessonIds))
            .putString("best_test", encodeIntMap(s.bestTestPercent))
            .putInt("correct", s.correctAnswers)
            .putInt("total", s.totalAnswers)
            .putString("review", encodeItems(s.reviewItems))
            .putInt("mastered", s.masteredCount)
            .putString("error_kinds", encodeIntMap(s.errorKindCounts))
            .putString("favorites", encodeSet(s.favoriteFormulaIds))
            .putInt("streak", s.streak)
            .putInt("best_streak", s.bestStreak)
            .putLong("last_active", s.lastActiveDay)
            .putLong("day_key", s.dayKey)
            .putInt("xp_today", s.xpToday)
            .putInt("correct_today", s.correctToday)
            .putInt("reviewed_today", s.reviewedToday)
            .putLong("bonus_day", s.bonusDay)
            .putInt("daily_bonus_count", s.dailyBonusCount)
            .putString("achievements", encodeSet(s.unlockedAchievements))
            .putInt("perfect_tests", s.perfectTests)
            .putInt("quick_sessions", s.quickSessions)
            .putInt("exams_done", s.examsDone)
            .putInt("best_exam", s.bestExamPercent)
            .putString("last_lesson", s.lastLessonId)
            .apply()
    }

    fun clear() {
        prefs.edit().clear().apply()
    }

    /** Carries over progress saved by version 0.4 (XP, finished lessons, mistakes). */
    private fun migrateLegacy(): AppState {
        return try {
            val old = app.getSharedPreferences("physico_progress", Context.MODE_PRIVATE)
            if (!old.contains("total_xp")) {
                AppState()
            } else {
                val today = Rules.today()
                val mistakes = old.getStringSet("mistake_question_ids", emptySet()) ?: emptySet()
                val items = HashMap<String, ReviewItem>()
                for (id in mistakes) {
                    items[id] = ReviewItem(id, 0, today)
                }
                AppState(
                    totalXp = old.getInt("total_xp", 0),
                    completedLessonIds = (old.getStringSet("completed_lessons", emptySet()) ?: emptySet()).toSet(),
                    correctAnswers = old.getInt("correct_answers", 0),
                    totalAnswers = old.getInt("total_answers", 0),
                    reviewItems = items
                )
            }
        } catch (e: Exception) {
            AppState()
        }
    }

    private fun parseGender(name: String?): Gender =
        Gender.entries.firstOrNull { it.name == name } ?: Gender.MALE

    private fun encodeSet(set: Set<String>): String = set.joinToString(",")

    private fun decodeSet(raw: String?): Set<String> =
        if (raw.isNullOrEmpty()) emptySet() else raw.split(",").filter { it.isNotEmpty() }.toSet()

    private fun encodeIntMap(map: Map<String, Int>): String =
        map.entries.joinToString(",") { it.key + "=" + it.value }

    private fun decodeIntMap(raw: String?): Map<String, Int> {
        if (raw.isNullOrEmpty()) return emptyMap()
        val result = HashMap<String, Int>()
        for (part in raw.split(",")) {
            val pieces = part.split("=")
            if (pieces.size == 2) {
                val value = pieces[1].toIntOrNull()
                if (value != null) result[pieces[0]] = value
            }
        }
        return result
    }

    private fun encodeItems(map: Map<String, ReviewItem>): String =
        map.values.joinToString(";") { it.key + "|" + it.box + "|" + it.dueDay }

    private fun decodeItems(raw: String?): Map<String, ReviewItem> {
        if (raw.isNullOrEmpty()) return emptyMap()
        val result = HashMap<String, ReviewItem>()
        for (part in raw.split(";")) {
            val pieces = part.split("|")
            if (pieces.size == 3) {
                val box = pieces[1].toIntOrNull()
                val due = pieces[2].toLongOrNull()
                if (box != null && due != null) result[pieces[0]] = ReviewItem(pieces[0], box, due)
            }
        }
        return result
    }

    companion object {
        private const val K_SAVED = "saved"
    }
}
