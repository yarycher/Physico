package by.physico.app.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import by.physico.app.data.Engine
import by.physico.app.data.ErrorKind
import by.physico.app.data.Rules
import by.physico.app.ui.theme.PhysicoColors

@Composable
fun ReviewScreen(controller: AppController, modifier: Modifier = Modifier) {
    val s = controller.state
    val today = Rules.today()
    val cs = MaterialTheme.colorScheme
    val ex = PhysicoColors.extra

    val dueQuestions = Engine.dueQuestions(s, today)
    val dueCards = Engine.dueFormulas(s, today)
    val dueTotal = dueQuestions.size + dueCards.size
    val mistakes = Engine.mistakeQuestions(s)

    var todayCount = 0
    var tomorrowCount = 0
    var weekCount = 0
    var laterCount = 0
    var nextDue = Long.MAX_VALUE
    for (item in s.reviewItems.values) {
        if (item.dueDay <= today) todayCount += 1
        else {
            if (item.dueDay < nextDue) nextDue = item.dueDay
            if (item.dueDay == today + 1) tomorrowCount += 1
            else if (item.dueDay <= today + 7) weekCount += 1
            else laterCount += 1
        }
    }
    val scheduledTotal = s.reviewItems.size

    PageList(modifier) {
        item {
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(text = "Повторение 🔁", style = MaterialTheme.typography.headlineMedium)
                Text(
                    text = "Материал возвращается через 1, 3, 7 и 14 дней. Ошибка отправляет задание в начало цепочки.",
                    style = MaterialTheme.typography.bodyLarge,
                    color = cs.onSurfaceVariant
                )
            }
        }

        item {
            if (dueTotal > 0) {
                AppCard(containerColor = cs.primaryContainer, borderColor = cs.primary) {
                    Text(
                        text = "Сегодня пора повторить",
                        style = MaterialTheme.typography.labelLarge,
                        color = cs.onPrimaryContainer
                    )
                    Text(
                        text = dueTotal.toString() + " " + pluralRu(dueTotal, "задание", "задания", "заданий"),
                        style = MaterialTheme.typography.headlineMedium,
                        color = cs.onPrimaryContainer
                    )
                    Text(
                        text = "Вопросов: " + dueQuestions.size.toString() + " · карточек формул: " + dueCards.size.toString(),
                        color = cs.onPrimaryContainer
                    )
                    Spacer(Modifier.height(14.dp))
                    if (dueQuestions.isNotEmpty()) {
                        PrimaryButton(
                            text = "Начать повторение (до 10 вопросов)",
                            onClick = { controller.startReview() }
                        )
                    }
                    if (dueCards.isNotEmpty()) {
                        Spacer(Modifier.height(10.dp))
                        if (dueQuestions.isNotEmpty()) {
                            SecondaryButton(
                                text = "Карточки формул (" + dueCards.size.toString() + ")",
                                onClick = { controller.startDueCards() }
                            )
                        } else {
                            PrimaryButton(
                                text = "Карточки формул (" + dueCards.size.toString() + ")",
                                onClick = { controller.startDueCards() }
                            )
                        }
                    }
                }
            } else {
                AppCard(containerColor = ex.successContainer, borderColor = ex.success) {
                    Text(
                        text = "На сегодня всё повторено ✨",
                        style = MaterialTheme.typography.titleLarge,
                        color = ex.onSuccessContainer
                    )
                    Spacer(Modifier.height(6.dp))
                    val text = if (scheduledTotal == 0) {
                        "Пройди урок, и его материал сам попадёт в график повторения."
                    } else if (nextDue == today + 1) {
                        "Следующее повторение: завтра."
                    } else if (nextDue != Long.MAX_VALUE) {
                        "Следующее повторение: через " + (nextDue - today).toString() + " дн."
                    } else {
                        "Заданий в графике пока нет."
                    }
                    Text(text = text, color = ex.onSuccessContainer)
                }
            }
        }

        item {
            AppCard {
                Text(text = "Работа над ошибками", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(4.dp))
                if (mistakes.isEmpty()) {
                    Text(
                        text = "Ошибок в очереди нет. Ошибочные ответы будут собираться здесь автоматически.",
                        color = cs.onSurfaceVariant
                    )
                } else {
                    Text(
                        text = "К исправлению: " + mistakes.size.toString(),
                        color = cs.error,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(Modifier.height(8.dp))
                    for (q in mistakes.take(3)) {
                        Text(
                            text = "• " + q.prompt,
                            style = MaterialTheme.typography.bodyMedium,
                            maxLines = 2
                        )
                        Spacer(Modifier.height(4.dp))
                    }
                    if (mistakes.size > 3) {
                        Text(
                            text = "…и ещё " + (mistakes.size - 3).toString(),
                            style = MaterialTheme.typography.bodySmall,
                            color = cs.onSurfaceVariant
                        )
                    }
                    Spacer(Modifier.height(12.dp))
                    PrimaryButton(text = "Исправить ошибки", onClick = { controller.startMistakes() })
                }
            }
        }

        item {
            AppCard {
                Text(text = "График повторений", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(8.dp))
                ScheduleRow("Сегодня", todayCount, scheduledTotal)
                ScheduleRow("Завтра", tomorrowCount, scheduledTotal)
                ScheduleRow("Через 2–7 дней", weekCount, scheduledTotal)
                ScheduleRow("Позже", laterCount, scheduledTotal)
                Spacer(Modifier.height(8.dp))
                Text(
                    text = "Полностью закреплено заданий: " + s.masteredCount.toString(),
                    style = MaterialTheme.typography.bodySmall,
                    color = cs.onSurfaceVariant
                )
            }
        }

        item {
            AppCard {
                Text(text = "Причины ошибок", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(4.dp))
                val totalKinds = s.errorKindCounts.values.sum()
                if (totalKinds == 0) {
                    Text(
                        text = "После неверного ответа отметь, почему ошибся: так видно, что подтянуть в первую очередь.",
                        color = cs.onSurfaceVariant
                    )
                } else {
                    Spacer(Modifier.height(6.dp))
                    for (kind in ErrorKind.entries) {
                        val count = s.errorKindCounts[kind.name] ?: 0
                        ScheduleRow(kind.label, count, totalKinds)
                    }
                }
            }
        }

        item {
            AppCard(onClick = { controller.openFormulaBook() }) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(text = "📖", style = MaterialTheme.typography.headlineMedium)
                    Spacer(Modifier.width(12.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(text = "Справочник формул", style = MaterialTheme.typography.titleMedium)
                        Text(
                            text = "Все формулы курса, избранное и расшифровка обозначений",
                            style = MaterialTheme.typography.bodySmall,
                            color = cs.onSurfaceVariant
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun ScheduleRow(label: String, count: Int, total: Int) {
    val cs = MaterialTheme.colorScheme
    Column(modifier = Modifier.padding(vertical = 4.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(text = label, modifier = Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium)
            Text(text = count.toString(), fontWeight = FontWeight.Bold, color = cs.primary)
        }
        Spacer(Modifier.height(4.dp))
        ProgressBar(
            fraction = if (total == 0) 0f else count.toFloat() / total,
            barHeight = 6.dp
        )
    }
}
