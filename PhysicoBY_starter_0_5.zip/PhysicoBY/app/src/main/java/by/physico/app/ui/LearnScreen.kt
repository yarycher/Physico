package by.physico.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import by.physico.app.data.Engine
import by.physico.app.data.Lesson
import by.physico.app.data.Rules
import by.physico.app.data.Topic
import by.physico.app.ui.theme.PhysicoColors

private enum class NodeState { DONE, CURRENT, LOCKED }

@Composable
fun LearnScreen(controller: AppController, modifier: Modifier = Modifier) {
    val s = controller.state
    val today = Rules.today()
    val cs = MaterialTheme.colorScheme
    val ex = PhysicoColors.extra
    val level = Rules.levelOf(s.totalXp)
    val levelStart = Rules.levelStartXp(level)
    val levelEnd = Rules.levelEndXp(level)
    val stage = Rules.stageOf(s)
    val streak = Rules.effectiveStreak(s, today)
    val next = controller.nextLesson()
    val tasks = Engine.dailyTasks(s)
    val allDone = tasks.all { it.done }

    PageList(modifier) {
        item {
            AppCard {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    CharacterAvatar(gender = s.gender, stage = stage, size = 72.dp)
                    Spacer(Modifier.width(14.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Уровень " + level.toString() + " · " + stage.title,
                            style = MaterialTheme.typography.titleMedium
                        )
                        Spacer(Modifier.height(6.dp))
                        ProgressBar(
                            fraction = (s.totalXp - levelStart).toFloat() / (levelEnd - levelStart),
                            color = ex.gold
                        )
                        Spacer(Modifier.height(4.dp))
                        Text(
                            text = s.totalXp.toString() + " / " + levelEnd.toString() + " XP до следующего уровня",
                            style = MaterialTheme.typography.labelMedium,
                            color = cs.onSurfaceVariant
                        )
                    }
                }
                Spacer(Modifier.height(12.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Pill(
                        text = "🔥 " + streak.toString() + " " + pluralRu(streak, "день", "дня", "дней"),
                        container = cs.tertiaryContainer,
                        content = cs.onTertiaryContainer
                    )
                    Pill(text = "⭐ " + s.totalXp.toString() + " XP")
                    Pill(text = "📚 " + s.completedLessonIds.size.toString() + "/" + by.physico.app.data.PhysicsCatalog.allLessons.size.toString())
                }
            }
        }

        item {
            if (next != null) {
                val started = s.lastLessonId.isNotEmpty()
                AppCard(containerColor = cs.primaryContainer, borderColor = cs.primary) {
                    Text(
                        text = if (started) "Продолжить обучение" else "Начни обучение",
                        style = MaterialTheme.typography.labelLarge,
                        color = cs.onPrimaryContainer
                    )
                    Spacer(Modifier.height(4.dp))
                    Text(
                        text = next.title,
                        style = MaterialTheme.typography.headlineSmall,
                        color = cs.onPrimaryContainer
                    )
                    Text(
                        text = lessonMeta(next),
                        style = MaterialTheme.typography.bodyMedium,
                        color = cs.onPrimaryContainer
                    )
                    Spacer(Modifier.height(14.dp))
                    PrimaryButton(
                        text = if (started) "Продолжить урок" else "Начать урок",
                        onClick = { controller.openLessonById(next.id) }
                    )
                }
            } else {
                AppCard(containerColor = ex.successContainer, borderColor = ex.success) {
                    Text(
                        text = "Курс пройден! 🏆",
                        style = MaterialTheme.typography.headlineSmall,
                        color = ex.onSuccessContainer
                    )
                    Spacer(Modifier.height(6.dp))
                    Text(
                        text = "Теперь закрепляй материал в повторении и проверяй себя на пробном экзамене.",
                        color = ex.onSuccessContainer
                    )
                    Spacer(Modifier.height(12.dp))
                    PrimaryButton(
                        text = "К пробному экзамену",
                        onClick = { controller.tab = MainTab.EXAM }
                    )
                }
            }
        }

        item {
            AppCard {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "Задания на сегодня",
                        style = MaterialTheme.typography.titleMedium,
                        modifier = Modifier.weight(1f)
                    )
                    if (allDone) {
                        Pill(text = "Все выполнены ✅", container = ex.successContainer, content = ex.onSuccessContainer)
                    }
                }
                Spacer(Modifier.height(10.dp))
                for (task in tasks) {
                    Column(modifier = Modifier.padding(vertical = 6.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(text = task.emoji + "  " + task.title, modifier = Modifier.weight(1f))
                            Text(
                                text = minOf(task.current, task.goal).toString() + "/" + task.goal.toString(),
                                fontWeight = FontWeight.Bold,
                                color = if (task.done) ex.success else cs.onSurfaceVariant
                            )
                        }
                        Spacer(Modifier.height(6.dp))
                        ProgressBar(
                            fraction = task.fraction,
                            color = if (task.done) ex.success else cs.primary
                        )
                    }
                }
                Spacer(Modifier.height(6.dp))
                Text(
                    text = "Выполни все три задания и получи +" + Rules.DAILY_BONUS_XP.toString() + " XP.",
                    style = MaterialTheme.typography.bodySmall,
                    color = cs.onSurfaceVariant
                )
            }
        }

        item { SectionTitle("Карта обучения") }

        for (topic in by.physico.app.data.PhysicsCatalog.subject.topics) {
            item {
                TopicMap(topic = topic, controller = controller)
            }
        }

        item {
            Text(
                text = "Задания в приложении авторские, тренировочные. Они не являются официальными материалами РИКЗ.",
                style = MaterialTheme.typography.bodySmall,
                color = cs.onSurfaceVariant
            )
        }
    }
}

private fun lessonMeta(lesson: Lesson): String =
    lesson.estimatedMinutes.toString() + " мин · " +
        lesson.practice.size.toString() + " упражнения · тест из " + lesson.test.size.toString() + " вопросов"

@Composable
private fun TopicMap(topic: Topic, controller: AppController) {
    val cs = MaterialTheme.colorScheme
    val ex = PhysicoColors.extra
    val completed = controller.state.completedLessonIds
    val doneCount = topic.lessons.count { completed.contains(it.id) }

    AppCard {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(text = topic.emoji, fontSize = 28.sp)
            Spacer(Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(text = topic.title, style = MaterialTheme.typography.titleMedium)
                Text(
                    text = topic.description,
                    style = MaterialTheme.typography.bodySmall,
                    color = cs.onSurfaceVariant
                )
            }
            Pill(
                text = doneCount.toString() + "/" + topic.lessons.size.toString(),
                container = if (doneCount == topic.lessons.size && doneCount > 0) ex.successContainer else cs.surfaceVariant,
                content = if (doneCount == topic.lessons.size && doneCount > 0) ex.onSuccessContainer else cs.onSurfaceVariant
            )
        }
        Spacer(Modifier.height(10.dp))
        ProgressBar(
            fraction = if (topic.lessons.isEmpty()) 0f else doneCount.toFloat() / topic.lessons.size,
            color = ex.success
        )
        Spacer(Modifier.height(10.dp))
        if (topic.lessons.isEmpty()) {
            Text(text = "Материалы готовятся", color = cs.primary)
        }
        for (i in topic.lessons.indices) {
            val lesson = topic.lessons[i]
            val nodeState = if (completed.contains(lesson.id)) NodeState.DONE
            else if (controller.isUnlocked(topic, i)) NodeState.CURRENT
            else NodeState.LOCKED
            LessonRow(
                number = i + 1,
                lesson = lesson,
                nodeState = nodeState,
                isLast = i == topic.lessons.size - 1,
                onClick = { controller.openLesson(topic, i) }
            )
        }
    }
}

@Composable
private fun LessonRow(
    number: Int,
    lesson: Lesson,
    nodeState: NodeState,
    isLast: Boolean,
    onClick: () -> Unit
) {
    val cs = MaterialTheme.colorScheme
    val ex = PhysicoColors.extra
    val nodeColor: Color = when (nodeState) {
        NodeState.DONE -> ex.success
        NodeState.CURRENT -> cs.primary
        NodeState.LOCKED -> cs.surfaceVariant
    }
    val nodeText: String = when (nodeState) {
        NodeState.DONE -> "✓"
        NodeState.CURRENT -> number.toString()
        NodeState.LOCKED -> "🔒"
    }
    val nodeTextColor: Color = when (nodeState) {
        NodeState.DONE -> ex.onSuccess
        NodeState.CURRENT -> cs.onPrimary
        NodeState.LOCKED -> cs.onSurfaceVariant
    }
    Row(
        modifier = Modifier.fillMaxWidth().clickable(onClick = onClick),
        verticalAlignment = Alignment.Top
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.width(44.dp)) {
            Box(
                modifier = Modifier.size(44.dp).clip(CircleShape).background(nodeColor),
                contentAlignment = Alignment.Center
            ) {
                Text(text = nodeText, color = nodeTextColor, fontWeight = FontWeight.Bold, fontSize = 18.sp)
            }
            if (!isLast) {
                Box(
                    modifier = Modifier
                        .width(4.dp)
                        .height(22.dp)
                        .background(cs.outlineVariant)
                )
            }
        }
        Spacer(Modifier.width(14.dp))
        Column(modifier = Modifier.weight(1f).padding(top = 2.dp, bottom = 10.dp)) {
            Text(
                text = lesson.title,
                style = MaterialTheme.typography.titleSmall,
                color = if (nodeState == NodeState.LOCKED) cs.onSurfaceVariant else cs.onSurface
            )
            Text(
                text = lesson.summary,
                style = MaterialTheme.typography.bodySmall,
                color = cs.onSurfaceVariant
            )
            Text(
                text = lessonMeta(lesson),
                style = MaterialTheme.typography.labelSmall,
                color = cs.onSurfaceVariant
            )
        }
    }
}
