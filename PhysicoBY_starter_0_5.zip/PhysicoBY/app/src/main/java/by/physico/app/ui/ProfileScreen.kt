package by.physico.app.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import by.physico.app.data.Achievements
import by.physico.app.data.CharacterStage
import by.physico.app.data.Gender
import by.physico.app.data.Rules
import by.physico.app.ui.theme.PhysicoColors

@Composable
fun ProfileScreen(controller: AppController, modifier: Modifier = Modifier) {
    val s = controller.state
    val today = Rules.today()
    val cs = MaterialTheme.colorScheme
    val ex = PhysicoColors.extra
    val growth = Rules.growthPoints(s)
    val stage = Rules.stageOf(s)
    val nextStage = stage.next()
    val level = Rules.levelOf(s.totalXp)
    val accuracy = if (s.totalAnswers == 0) 0 else s.correctAnswers * 100 / s.totalAnswers
    val streak = Rules.effectiveStreak(s, today)
    var showReset by remember { mutableStateOf(false) }

    if (showReset) {
        AlertDialog(
            onDismissRequest = { showReset = false },
            title = { Text("Сбросить весь прогресс?") },
            text = { Text("Опыт, пройденные уроки, график повторения и достижения будут удалены. Это действие нельзя отменить.") },
            confirmButton = {
                TextButton(onClick = {
                    showReset = false
                    controller.resetAll()
                }) { Text("Сбросить", color = cs.error) }
            },
            dismissButton = {
                TextButton(onClick = { showReset = false }) { Text("Отмена") }
            }
        )
    }

    PageList(modifier) {
        item {
            AppCard {
                Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
                    CharacterAvatar(gender = s.gender, stage = stage, size = 150.dp)
                    Spacer(Modifier.height(10.dp))
                    Text(text = stage.title, style = MaterialTheme.typography.headlineMedium)
                    Text(
                        text = stage.tagline,
                        style = MaterialTheme.typography.bodyMedium,
                        color = cs.onSurfaceVariant,
                        textAlign = TextAlign.Center
                    )
                    Spacer(Modifier.height(14.dp))
                    if (nextStage != null) {
                        val span = nextStage.minGrowth - stage.minGrowth
                        ProgressBar(
                            fraction = (growth - stage.minGrowth).toFloat() / span,
                            color = cs.secondary
                        )
                        Spacer(Modifier.height(6.dp))
                        Text(
                            text = "Очки роста: " + growth.toString() + " / " + nextStage.minGrowth.toString() +
                                " до стадии «" + nextStage.title + "»",
                            style = MaterialTheme.typography.labelMedium,
                            color = cs.onSurfaceVariant
                        )
                    } else {
                        Text(
                            text = "Максимальная стадия достигнута. Очки роста: " + growth.toString(),
                            style = MaterialTheme.typography.labelMedium,
                            color = cs.onSurfaceVariant
                        )
                    }
                }
            }
        }

        item {
            AppCard {
                Text(text = "Стадии развития", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(10.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    for (st in CharacterStage.entries) {
                        val unlocked = growth >= st.minGrowth
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            modifier = Modifier.alpha(if (unlocked) 1f else 0.35f)
                        ) {
                            CharacterAvatar(gender = s.gender, stage = st, size = 52.dp, showBadge = false)
                            Spacer(Modifier.height(4.dp))
                            Text(
                                text = st.title,
                                fontSize = 10.sp,
                                maxLines = 1,
                                fontWeight = if (st == stage) FontWeight.Bold else FontWeight.Normal
                            )
                        }
                    }
                }
                Spacer(Modifier.height(10.dp))
                Text(
                    text = "Персонаж растёт от очков роста: урок +10, пробный экзамен +5, ежедневные задания +3, закреплённое задание +1. Ошибки внешний вид не ухудшают. Рост не зависит от XP и уровня.",
                    style = MaterialTheme.typography.bodySmall,
                    color = cs.onSurfaceVariant
                )
            }
        }

        item { SectionTitle("Статистика") }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                StatTile("Уровень", level.toString(), Modifier.weight(1f))
                StatTile("Опыт", s.totalXp.toString() + " XP", Modifier.weight(1f))
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                StatTile("Серия дней 🔥", streak.toString(), Modifier.weight(1f))
                StatTile("Лучшая серия", s.bestStreak.toString(), Modifier.weight(1f))
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                StatTile("Уроков пройдено", s.completedLessonIds.size.toString(), Modifier.weight(1f))
                StatTile("Точность", accuracy.toString() + "%", Modifier.weight(1f))
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                StatTile("Закреплено заданий", s.masteredCount.toString(), Modifier.weight(1f))
                StatTile("Пробных экзаменов", s.examsDone.toString(), Modifier.weight(1f))
            }
        }

        item {
            SectionTitle(
                "Достижения (" + s.unlockedAchievements.size.toString() + "/" + Achievements.all.size.toString() + ")"
            )
        }
        items(Achievements.all.size) { i ->
            val a = Achievements.all[i]
            val current = a.current(s)
            val unlocked = s.unlockedAchievements.contains(a.id) || current >= a.target
            AppCard(
                containerColor = if (unlocked) ex.successContainer else cs.surface,
                borderColor = if (unlocked) ex.success else cs.outlineVariant
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = a.emoji,
                        fontSize = 30.sp,
                        modifier = Modifier.alpha(if (unlocked) 1f else 0.4f)
                    )
                    Spacer(Modifier.width(14.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = a.title,
                            style = MaterialTheme.typography.titleSmall,
                            color = if (unlocked) ex.onSuccessContainer else cs.onSurface
                        )
                        Text(
                            text = a.description,
                            style = MaterialTheme.typography.bodySmall,
                            color = if (unlocked) ex.onSuccessContainer else cs.onSurfaceVariant
                        )
                        if (!unlocked) {
                            Spacer(Modifier.height(6.dp))
                            ProgressBar(
                                fraction = current.toFloat() / a.target,
                                barHeight = 6.dp
                            )
                        }
                    }
                    Spacer(Modifier.width(10.dp))
                    Text(
                        text = if (unlocked) "✓" else minOf(current, a.target).toString() + "/" + a.target.toString(),
                        fontWeight = FontWeight.Bold,
                        color = if (unlocked) ex.success else cs.onSurfaceVariant
                    )
                }
            }
        }

        item { SectionTitle("Настройки") }
        item {
            AppCard {
                Text(text = "Персонаж", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    for (g in Gender.entries) {
                        ChoiceChip(
                            text = g.label,
                            selected = s.gender == g,
                            onClick = { controller.changeGender(g) }
                        )
                    }
                }
                Spacer(Modifier.height(16.dp))
                SecondaryButton(text = "Сбросить прогресс", onClick = { showReset = true })
            }
        }
        item {
            Text(
                text = "Physico BY 0.5. Прогресс хранится на этом устройстве, интернет не нужен. Задания авторские и тренировочные, это не официальные материалы РИКЗ.",
                style = MaterialTheme.typography.bodySmall,
                color = cs.onSurfaceVariant,
                modifier = Modifier.padding(bottom = 8.dp)
            )
        }
    }
}

@Composable
private fun StatTile(label: String, value: String, modifier: Modifier = Modifier) {
    val cs = MaterialTheme.colorScheme
    AppCard(modifier = modifier) {
        Text(text = label, style = MaterialTheme.typography.labelMedium, color = cs.onSurfaceVariant)
        Spacer(Modifier.height(4.dp))
        Text(text = value, style = MaterialTheme.typography.headlineSmall, color = cs.primary)
    }
}
