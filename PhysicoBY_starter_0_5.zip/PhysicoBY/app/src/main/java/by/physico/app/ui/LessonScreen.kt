package by.physico.app.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.width
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import by.physico.app.data.ErrorKind
import by.physico.app.data.Lesson
import by.physico.app.data.Question
import by.physico.app.ui.theme.PhysicoColors

private enum class LessonStage { THEORY, PRACTICE, TEST, RESULT }

@Composable
fun LessonScreen(
    lesson: Lesson,
    alreadyCompleted: Boolean,
    onAnswer: (Question, Boolean) -> Unit,
    onErrorKind: (ErrorKind) -> Unit,
    onComplete: (Int, Int, Int) -> Unit,
    onExit: () -> Unit
) {
    var stage by remember(lesson.id) { mutableStateOf(LessonStage.THEORY) }
    var attempt by remember(lesson.id) { mutableIntStateOf(0) }
    var practiceCorrect by remember(lesson.id) { mutableIntStateOf(0) }
    var testCorrect by remember(lesson.id) { mutableIntStateOf(0) }
    var testWrong by remember(lesson.id) { mutableStateOf<List<Question>>(emptyList()) }

    BackHandler(enabled = stage == LessonStage.THEORY || stage == LessonStage.RESULT) {
        onExit()
    }

    when (stage) {
        LessonStage.THEORY -> TheoryStage(
            lesson = lesson,
            onStart = {
                stage = if (lesson.practice.isEmpty()) LessonStage.TEST else LessonStage.PRACTICE
            },
            onExit = onExit
        )
        LessonStage.PRACTICE -> key(attempt) {
            QuizRunner(
                title = "Тренировка · " + lesson.title,
                questions = lesson.practice,
                instantFeedback = true,
                timeLimitSec = 0,
                askErrorKind = true,
                hintText = lesson.formulas.joinToString("\n") { it.title + ": " + it.expression },
                onAnswered = onAnswer,
                onErrorKind = onErrorKind,
                onFinished = { result ->
                    practiceCorrect = result.correct
                    stage = LessonStage.TEST
                },
                onExit = onExit
            )
        }
        LessonStage.TEST -> key(attempt) {
            QuizRunner(
                title = "Итоговый тест · " + lesson.title,
                questions = lesson.test,
                instantFeedback = true,
                timeLimitSec = 0,
                askErrorKind = true,
                hintText = null,
                onAnswered = onAnswer,
                onErrorKind = onErrorKind,
                onFinished = { result ->
                    testCorrect = result.correct
                    testWrong = result.wrong
                    stage = LessonStage.RESULT
                },
                onExit = onExit
            )
        }
        LessonStage.RESULT -> {
            val percent = if (lesson.test.isEmpty()) 100 else testCorrect * 100 / lesson.test.size
            val passed = percent >= lesson.passingPercent
            val xpPreview = if (alreadyCompleted) 0 else (practiceCorrect + testCorrect) * 10 + 20
            val cs = MaterialTheme.colorScheme
            val ex = PhysicoColors.extra
            PageList {
                item {
                    ScreenHeader(title = "Результат теста", onBack = onExit)
                }
                item {
                    AppCard(
                        containerColor = if (passed) ex.successContainer else cs.errorContainer,
                        borderColor = if (passed) ex.success else cs.error
                    ) {
                        Text(
                            text = if (passed) "Урок усвоен! 🎉" else "Нужно немного повторить",
                            style = MaterialTheme.typography.headlineSmall,
                            color = if (passed) ex.onSuccessContainer else cs.onErrorContainer
                        )
                        Spacer(Modifier.height(8.dp))
                        Text(
                            text = "Правильных ответов: " + testCorrect.toString() + " из " + lesson.test.size.toString(),
                            style = MaterialTheme.typography.titleMedium,
                            color = if (passed) ex.onSuccessContainer else cs.onErrorContainer
                        )
                        Spacer(Modifier.height(10.dp))
                        ProgressBar(
                            fraction = percent / 100f,
                            color = if (passed) ex.success else cs.error,
                            track = cs.surface
                        )
                        Spacer(Modifier.height(8.dp))
                        Text(
                            text = "Результат: " + percent.toString() + "%. Проходной балл: " + lesson.passingPercent.toString() + "%.",
                            color = if (passed) ex.onSuccessContainer else cs.onErrorContainer
                        )
                    }
                }
                item {
                    if (passed) {
                        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            PrimaryButton(
                                text = if (xpPreview > 0) "Завершить урок · +" + xpPreview.toString() + " XP" else "Завершить урок",
                                onClick = { onComplete(practiceCorrect, testCorrect, percent) }
                            )
                            Text(
                                text = "Материал урока автоматически попадёт в повторение: через 1, 3, 7 и 14 дней.",
                                style = MaterialTheme.typography.bodySmall,
                                color = cs.onSurfaceVariant
                            )
                        }
                    } else {
                        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            PrimaryButton(
                                text = "Повторить тест",
                                onClick = {
                                    attempt += 1
                                    testCorrect = 0
                                    testWrong = emptyList()
                                    stage = LessonStage.TEST
                                }
                            )
                            SecondaryButton(
                                text = "Вернуться к теории",
                                onClick = {
                                    testCorrect = 0
                                    testWrong = emptyList()
                                    stage = LessonStage.THEORY
                                }
                            )
                            Text(
                                text = "Урок засчитывается только после теста на " + lesson.passingPercent.toString() + "% и выше.",
                                style = MaterialTheme.typography.bodySmall,
                                color = cs.onSurfaceVariant
                            )
                        }
                    }
                }
                if (testWrong.isNotEmpty()) {
                    item { SectionTitle("Разбор ошибок") }
                    items(testWrong.size) { i ->
                        WrongAnswerCard(testWrong[i])
                    }
                }
            }
        }
    }
}

@Composable
private fun StepBar(current: Int) {
    val cs = MaterialTheme.colorScheme
    val labels = listOf("Теория", "Практика", "Тест")
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
        for (i in labels.indices) {
            Column(modifier = Modifier.weight(1f)) {
                ProgressBar(
                    fraction = if (i <= current) 1f else 0f,
                    color = if (i == current) cs.primary else cs.secondary,
                    barHeight = 6.dp
                )
                Spacer(Modifier.height(4.dp))
                Text(
                    text = (i + 1).toString() + ". " + labels[i],
                    style = MaterialTheme.typography.labelMedium,
                    color = if (i == current) cs.primary else cs.onSurfaceVariant,
                    fontWeight = if (i == current) FontWeight.Bold else FontWeight.Normal
                )
            }
        }
    }
}

@Composable
private fun TheoryStage(
    lesson: Lesson,
    onStart: () -> Unit,
    onExit: () -> Unit
) {
    val cs = MaterialTheme.colorScheme
    Column(modifier = Modifier.fillMaxSize()) {
        Box(modifier = Modifier.weight(1f).fillMaxWidth()) {
            PageList {
                item { ScreenHeader(title = "Урок", onBack = onExit) }
                item {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        StepBar(current = 0)
                        Text(text = lesson.title, style = MaterialTheme.typography.headlineMedium)
                        Text(
                            text = lesson.summary,
                            style = MaterialTheme.typography.bodyLarge,
                            color = cs.onSurfaceVariant
                        )
                    }
                }
                item { SectionTitle("Теория") }
                items(lesson.theory.size) { i ->
                    AppCard {
                        Text(
                            text = lesson.theory[i],
                            style = MaterialTheme.typography.bodyLarge,
                            lineHeight = 24.sp
                        )
                    }
                }
                if (lesson.formulas.isNotEmpty()) {
                    item { SectionTitle("Формулы") }
                    items(lesson.formulas.size) { i ->
                        val f = lesson.formulas[i]
                        AppCard(containerColor = cs.primaryContainer, borderColor = cs.primaryContainer) {
                            Text(
                                text = f.title,
                                style = MaterialTheme.typography.titleSmall,
                                color = cs.onPrimaryContainer
                            )
                            Spacer(Modifier.height(8.dp))
                            Text(
                                text = f.expression,
                                style = MaterialTheme.typography.headlineSmall,
                                color = cs.onPrimaryContainer
                            )
                            Spacer(Modifier.height(6.dp))
                            Text(
                                text = f.legend,
                                style = MaterialTheme.typography.bodyMedium,
                                color = cs.onPrimaryContainer
                            )
                        }
                    }
                }
                if (lesson.examples.isNotEmpty()) {
                    item { SectionTitle("Разбор задачи") }
                    items(lesson.examples.size) { i ->
                        val e = lesson.examples[i]
                        AppCard {
                            Text(text = "Задача", style = MaterialTheme.typography.labelLarge, color = cs.primary)
                            Text(text = e.task, style = MaterialTheme.typography.bodyLarge)
                            Spacer(Modifier.height(10.dp))
                            Text(text = "Решение", style = MaterialTheme.typography.labelLarge, color = cs.primary)
                            for (s in e.steps.indices) {
                                Row(modifier = Modifier.padding(top = 4.dp)) {
                                    Text(
                                        text = (s + 1).toString() + ".",
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.width(24.dp)
                                    )
                                    Text(text = e.steps[s], modifier = Modifier.weight(1f))
                                }
                            }
                            Spacer(Modifier.height(10.dp))
                            Text(
                                text = "Ответ: " + e.answer,
                                fontWeight = FontWeight.Bold,
                                color = PhysicoColors.extra.success
                            )
                        }
                    }
                }
                item {
                    Text(
                        text = "Дальше: тренировка с подсказками и обязательный итоговый тест (проходной балл " +
                            lesson.passingPercent.toString() + "%).",
                        style = MaterialTheme.typography.bodyMedium,
                        color = cs.onSurfaceVariant,
                        textAlign = TextAlign.Start
                    )
                }
            }
        }
        Surface(tonalElevation = 3.dp, modifier = Modifier.fillMaxWidth()) {
            Box(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp),
                contentAlignment = Alignment.Center
            ) {
                Box(modifier = Modifier.widthIn(max = 640.dp)) {
                    PrimaryButton(text = "Перейти к тренировке", onClick = onStart)
                }
            }
        }
    }
}
