package by.physico.app.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.key
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import by.physico.app.data.Engine
import by.physico.app.data.PhysicsCatalog
import by.physico.app.data.ProgressStore
import by.physico.app.data.Rules
import kotlinx.coroutines.delay

@Composable
fun PhysicoApp() {
    val context = LocalContext.current
    val controller = remember { AppController(ProgressStore(context)) }
    val onboarded = controller.state.onboarded
    val screen = controller.screen

    BackHandler(enabled = onboarded && screen != null) {
        controller.closeScreen()
    }
    BackHandler(enabled = onboarded && screen == null && controller.tab != MainTab.LEARN) {
        controller.tab = MainTab.LEARN
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        if (!onboarded) {
            OnboardingScreen(onStart = { gender -> controller.chooseCharacter(gender) })
        } else if (screen != null) {
            Box(modifier = Modifier.fillMaxSize().systemBarsPadding()) {
                ScreenHost(controller = controller, screen = screen)
            }
        } else {
            MainScaffold(controller)
        }
        EventBanner(controller)
    }
}

@Composable
private fun MainScaffold(controller: AppController) {
    val dueCount = Engine.dueItems(controller.state, Rules.today()).size

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        bottomBar = {
            NavigationBar {
                for (tab in MainTab.entries) {
                    NavigationBarItem(
                        selected = controller.tab == tab,
                        onClick = { controller.tab = tab },
                        icon = {
                            if (tab == MainTab.REVIEW && dueCount > 0) {
                                BadgedBox(badge = { Badge { Text(dueCount.toString()) } }) {
                                    Text(text = tab.emoji, fontSize = 22.sp)
                                }
                            } else {
                                Text(text = tab.emoji, fontSize = 22.sp)
                            }
                        },
                        label = { Text(text = tab.title, maxLines = 1, fontSize = 11.sp) },
                        alwaysShowLabel = true
                    )
                }
            }
        }
    ) { innerPadding ->
        Box(modifier = Modifier.padding(innerPadding).fillMaxSize()) {
            when (controller.tab) {
                MainTab.LEARN -> LearnScreen(controller)
                MainTab.QUICK -> QuickScreen(controller)
                MainTab.REVIEW -> ReviewScreen(controller)
                MainTab.EXAM -> ExamScreen(controller)
                MainTab.PROFILE -> ProfileScreen(controller)
            }
        }
    }
}

@Composable
private fun ScreenHost(controller: AppController, screen: Screen) {
    when (screen) {
        is Screen.OpenLesson -> {
            val lesson = PhysicsCatalog.lessonById[screen.lessonId]
            if (lesson == null) {
                PageList {
                    item { ScreenHeader(title = "Урок не найден", onBack = { controller.closeScreen() }) }
                }
            } else {
                key(lesson.id) {
                    LessonScreen(
                        lesson = lesson,
                        alreadyCompleted = controller.state.completedLessonIds.contains(lesson.id),
                        onAnswer = { q, ok -> controller.recordAnswer(q, ok, null) },
                        onErrorKind = { kind -> controller.recordErrorKind(kind) },
                        onComplete = { practice, test, percent ->
                            controller.completeLesson(lesson, practice, test, percent)
                        },
                        onExit = { controller.closeScreen() }
                    )
                }
            }
        }
        is Screen.Quiz -> {
            val setup = screen.setup
            key(setup.id) {
                QuizRunner(
                    title = setup.title,
                    questions = setup.questions,
                    instantFeedback = setup.instantFeedback,
                    timeLimitSec = setup.timeLimitSec,
                    askErrorKind = setup.instantFeedback,
                    hintText = null,
                    onAnswered = { q, ok -> controller.recordAnswer(q, ok, setup.kind) },
                    onErrorKind = { kind -> controller.recordErrorKind(kind) },
                    onFinished = { result -> controller.finishSession(setup, result) },
                    onExit = { controller.closeScreen() }
                )
            }
        }
        is Screen.Cards -> {
            val setup = screen.setup
            key(setup.id) {
                CardRunner(
                    title = setup.title,
                    cards = setup.cards,
                    favorites = controller.state.favoriteFormulaIds,
                    onAnswer = { id, known -> controller.cardAnswer(id, known) },
                    onToggleFavorite = { id -> controller.toggleFavorite(id) },
                    onExit = { controller.closeScreen() }
                )
            }
        }
        is Screen.Result -> {
            ResultScreen(
                summary = screen.summary,
                onDone = { controller.closeScreen() },
                onRetryWrong = { wrong -> controller.retryWrong(wrong) }
            )
        }
        Screen.FormulaBook -> {
            FormulaBookScreen(controller)
        }
    }
}

@Composable
private fun EventBanner(controller: AppController) {
    val first = controller.events.firstOrNull()
    val cs = MaterialTheme.colorScheme

    LaunchedEffect(first?.id) {
        if (first != null) {
            delay(3500L)
            controller.dismissEvent()
        }
    }

    if (first != null) {
        Box(
            modifier = Modifier.fillMaxWidth().systemBarsPadding().padding(12.dp),
            contentAlignment = Alignment.TopCenter
        ) {
            Box(
                modifier = Modifier
                    .widthIn(max = 560.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .background(cs.inverseSurface)
                    .clickable { controller.dismissEvent() }
                    .padding(horizontal = 16.dp, vertical = 12.dp)
            ) {
                Text(
                    text = first.text,
                    color = cs.inverseOnSurface,
                    fontWeight = FontWeight.SemiBold
                )
            }
        }
    }
}
