package by.physico.app.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import by.physico.app.data.ErrorKind
import by.physico.app.data.Question
import by.physico.app.ui.theme.PhysicoColors
import kotlinx.coroutines.delay

private val OptionLetters = listOf("А", "Б", "В", "Г", "Д")

/**
 * One reusable question runner used by lessons, quick sessions, review and exams.
 * Create it inside `key(...)` so that a new session starts from the first question.
 */
@Composable
fun QuizRunner(
    title: String,
    questions: List<Question>,
    instantFeedback: Boolean,
    timeLimitSec: Int,
    askErrorKind: Boolean,
    hintText: String?,
    onAnswered: (Question, Boolean) -> Unit,
    onErrorKind: (ErrorKind) -> Unit,
    onFinished: (QuizResult) -> Unit,
    onExit: () -> Unit
) {
    val total = questions.size
    var index by remember { mutableIntStateOf(0) }
    var selected by remember { mutableIntStateOf(-1) }
    var checked by remember { mutableStateOf(false) }
    var answered by remember { mutableIntStateOf(0) }
    var correctCount by remember { mutableIntStateOf(0) }
    var wrong by remember { mutableStateOf<List<Question>>(emptyList()) }
    var errorChoice by remember { mutableStateOf<ErrorKind?>(null) }
    var showHint by remember { mutableStateOf(false) }
    var showExit by remember { mutableStateOf(false) }
    var elapsed by remember { mutableIntStateOf(0) }
    var finished by remember { mutableStateOf(false) }
    val finishCallback by rememberUpdatedState(onFinished)
    val scroll = rememberScrollState()

    fun finishNow() {
        if (finished) return
        finished = true
        val unanswered = questions.drop(answered)
        finishCallback(QuizResult(correctCount, total, wrong + unanswered, elapsed))
    }

    fun advance() {
        if (index + 1 >= total) {
            finishNow()
        } else {
            index += 1
            selected = -1
            checked = false
            errorChoice = null
            showHint = false
        }
    }

    fun submit() {
        val q = questions[index]
        val ok = selected == q.correctOptionIndex
        answered += 1
        if (ok) {
            correctCount += 1
        } else {
            wrong = wrong + q
        }
        onAnswered(q, ok)
        if (instantFeedback) {
            checked = true
        } else {
            advance()
        }
    }

    LaunchedEffect(Unit) {
        while (!finished) {
            delay(1000L)
            if (finished) break
            elapsed += 1
            if (timeLimitSec > 0 && elapsed >= timeLimitSec) {
                finishNow()
            }
        }
    }

    LaunchedEffect(index) {
        scroll.scrollTo(0)
    }

    LaunchedEffect(checked) {
        if (checked) {
            delay(60L)
            scroll.animateScrollTo(scroll.maxValue)
        }
    }

    BackHandler { showExit = true }

    if (showExit) {
        AlertDialog(
            onDismissRequest = { showExit = false },
            title = { Text("Выйти из занятия?") },
            text = { Text("Результат этого занятия не сохранится. Ответы, которые уже записаны, останутся в повторении.") },
            confirmButton = {
                TextButton(onClick = { showExit = false; onExit() }) { Text("Выйти") }
            },
            dismissButton = {
                TextButton(onClick = { showExit = false }) { Text("Остаться") }
            }
        )
    }

    val question = questions.getOrNull(index)
    val cs = MaterialTheme.colorScheme
    val ex = PhysicoColors.extra
    val isLast = index + 1 >= total

    Column(modifier = Modifier.fillMaxSize()) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = { showExit = true }) {
                Icon(Icons.Filled.Close, contentDescription = "Выйти")
            }
            ProgressBar(
                fraction = (index + (if (checked) 1 else 0)).toFloat() / total.coerceAtLeast(1),
                modifier = Modifier.weight(1f)
            )
            Spacer(Modifier.width(12.dp))
            if (timeLimitSec > 0) {
                val left = (timeLimitSec - elapsed).coerceAtLeast(0)
                Text(
                    text = "⏱ " + formatTime(left),
                    color = if (left <= 30) cs.error else cs.onSurfaceVariant,
                    fontWeight = FontWeight.Bold
                )
            } else {
                Text(
                    text = (index + 1).toString() + "/" + total.toString(),
                    color = cs.onSurfaceVariant,
                    fontWeight = FontWeight.Bold
                )
            }
            Spacer(Modifier.width(8.dp))
        }

        Box(modifier = Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.TopCenter) {
            Column(
                modifier = Modifier
                    .widthIn(max = 640.dp)
                    .fillMaxWidth()
                    .verticalScroll(scroll)
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(text = title, style = MaterialTheme.typography.labelLarge, color = cs.primary)
                if (question != null) {
                    Text(
                        text = "Вопрос " + (index + 1).toString() + " из " + total.toString(),
                        style = MaterialTheme.typography.labelMedium,
                        color = cs.onSurfaceVariant
                    )
                    Text(text = question.prompt, style = MaterialTheme.typography.titleLarge)

                    if (hintText != null && !checked) {
                        ChoiceChip(
                            text = if (showHint) "💡 Скрыть подсказку" else "💡 Подсказка: формулы урока",
                            selected = showHint,
                            onClick = { showHint = !showHint }
                        )
                        if (showHint) {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(14.dp))
                                    .background(cs.secondaryContainer)
                                    .padding(14.dp)
                            ) {
                                Text(text = hintText, color = cs.onSecondaryContainer)
                            }
                        }
                    }

                    question.options.forEachIndexed { i, option ->
                        val optionState = if (instantFeedback && checked) {
                            if (i == question.correctOptionIndex) OptionState.CORRECT
                            else if (i == selected) OptionState.WRONG
                            else OptionState.DIMMED
                        } else if (i == selected) {
                            OptionState.SELECTED
                        } else {
                            OptionState.IDLE
                        }
                        OptionCard(
                            letter = OptionLetters.getOrElse(i) { "•" },
                            text = option,
                            state = optionState,
                            enabled = !checked,
                            onClick = { selected = i }
                        )
                    }

                    if (instantFeedback && checked) {
                        val ok = selected == question.correctOptionIndex
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(16.dp))
                                .background(if (ok) ex.successContainer else cs.errorContainer)
                                .padding(16.dp)
                        ) {
                            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                Text(
                                    text = if (ok) "Верно! 🎉" else "Неверно",
                                    style = MaterialTheme.typography.titleMedium,
                                    color = if (ok) ex.onSuccessContainer else cs.onErrorContainer
                                )
                                if (!ok) {
                                    Text(
                                        text = "Правильный ответ: " + question.options[question.correctOptionIndex],
                                        fontWeight = FontWeight.SemiBold,
                                        color = cs.onErrorContainer
                                    )
                                }
                                Text(
                                    text = question.explanation,
                                    color = if (ok) ex.onSuccessContainer else cs.onErrorContainer
                                )
                            }
                        }
                        if (!ok && askErrorKind) {
                            Text(text = "Почему ошиблись?", style = MaterialTheme.typography.titleSmall)
                            val kinds = ErrorKind.entries
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                for (k in kinds.take(2)) {
                                    ChoiceChip(
                                        text = k.label,
                                        selected = errorChoice == k,
                                        onClick = {
                                            if (errorChoice == null) {
                                                errorChoice = k
                                                onErrorKind(k)
                                            }
                                        },
                                        modifier = Modifier.weight(1f)
                                    )
                                }
                            }
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                for (k in kinds.drop(2)) {
                                    ChoiceChip(
                                        text = k.label,
                                        selected = errorChoice == k,
                                        onClick = {
                                            if (errorChoice == null) {
                                                errorChoice = k
                                                onErrorKind(k)
                                            }
                                        },
                                        modifier = Modifier.weight(1f)
                                    )
                                }
                            }
                        }
                    }
                }
                Spacer(Modifier.height(8.dp))
            }
        }

        Surface(tonalElevation = 3.dp, modifier = Modifier.fillMaxWidth()) {
            Box(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp),
                contentAlignment = Alignment.Center
            ) {
                Box(modifier = Modifier.widthIn(max = 640.dp)) {
                    if (instantFeedback && checked) {
                        PrimaryButton(
                            text = if (isLast) "Завершить" else "Далее",
                            onClick = { advance() }
                        )
                    } else if (instantFeedback) {
                        PrimaryButton(
                            text = "Проверить",
                            onClick = { submit() },
                            enabled = selected >= 0
                        )
                    } else {
                        PrimaryButton(
                            text = if (isLast) "Ответить и завершить" else "Ответить",
                            onClick = { submit() },
                            enabled = selected >= 0
                        )
                    }
                }
            }
        }
    }
}
