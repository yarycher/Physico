package by.physico.app.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import by.physico.app.ui.theme.PhysicoColors

@Composable
fun ResultScreen(
    summary: SessionSummary,
    onDone: () -> Unit,
    onRetryWrong: (List<by.physico.app.data.Question>) -> Unit
) {
    val cs = MaterialTheme.colorScheme
    val ex = PhysicoColors.extra
    val percent = if (summary.total == 0) 0 else summary.correct * 100 / summary.total
    val good = percent >= 80
    val ok = percent >= 60
    val emoji = if (good) "🏆" else if (ok) "👍" else "💪"
    val headline = if (good) "Отличный результат!" else if (ok) "Хороший результат" else "Есть над чем поработать"

    BackHandler { onDone() }

    PageList {
        item { Spacer(Modifier.height(8.dp)) }
        item {
            AppCard(
                containerColor = if (ok) ex.successContainer else cs.tertiaryContainer,
                borderColor = if (ok) ex.success else cs.tertiary
            ) {
                Text(
                    text = emoji,
                    fontSize = 56.sp,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth()
                )
                Text(
                    text = headline,
                    style = MaterialTheme.typography.headlineSmall,
                    textAlign = TextAlign.Center,
                    color = if (ok) ex.onSuccessContainer else cs.onTertiaryContainer,
                    modifier = Modifier.fillMaxWidth()
                )
                Text(
                    text = summary.title,
                    textAlign = TextAlign.Center,
                    color = if (ok) ex.onSuccessContainer else cs.onTertiaryContainer,
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(12.dp))
                Text(
                    text = summary.correct.toString() + " из " + summary.total.toString() + "  ·  " + percent.toString() + "%",
                    style = MaterialTheme.typography.headlineMedium,
                    textAlign = TextAlign.Center,
                    color = if (ok) ex.onSuccessContainer else cs.onTertiaryContainer,
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(10.dp))
                ProgressBar(
                    fraction = percent / 100f,
                    color = if (ok) ex.success else cs.tertiary,
                    track = cs.surface
                )
                Spacer(Modifier.height(10.dp))
                val extra = if (summary.xpGained > 0) "  ·  +" + summary.xpGained.toString() + " XP" else ""
                Text(
                    text = "Время: " + formatTime(summary.timeSec) + extra,
                    textAlign = TextAlign.Center,
                    color = if (ok) ex.onSuccessContainer else cs.onTertiaryContainer,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }
        item {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                PrimaryButton(text = "Готово", onClick = onDone)
                if (summary.wrong.isNotEmpty()) {
                    SecondaryButton(
                        text = "Повторить ошибки (" + summary.wrong.size.toString() + ")",
                        onClick = { onRetryWrong(summary.wrong) }
                    )
                }
            }
        }
        if (summary.wrong.isNotEmpty()) {
            item {
                Text(
                    text = "Разбор ошибок",
                    style = MaterialTheme.typography.titleLarge
                )
            }
            items(summary.wrong.size) { i ->
                WrongAnswerCard(summary.wrong[i])
            }
        } else {
            item {
                Row {
                    Text(
                        text = "Ни одной ошибки. Так держать! ✨",
                        style = MaterialTheme.typography.titleMedium
                    )
                }
            }
        }
    }
}
