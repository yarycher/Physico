package by.physico.app.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import by.physico.app.data.CharacterStage
import by.physico.app.data.Gender

@Composable
fun OnboardingScreen(onStart: (Gender) -> Unit) {
    val cs = MaterialTheme.colorScheme
    var gender by remember { mutableStateOf(Gender.MALE) }

    Box(
        modifier = Modifier.fillMaxSize().systemBarsPadding(),
        contentAlignment = Alignment.TopCenter
    ) {
        Column(
            modifier = Modifier
                .widthIn(max = 560.dp)
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Spacer(Modifier.height(12.dp))
            Text(
                text = "Physico BY",
                style = MaterialTheme.typography.headlineMedium,
                color = cs.primary
            )
            Text(
                text = "Готовься к ЦЭ и ЦТ по физике шаг за шагом. Выбери персонажа: он будет расти вместе с твоими знаниями.",
                style = MaterialTheme.typography.bodyLarge,
                textAlign = TextAlign.Center,
                color = cs.onSurfaceVariant
            )
            Row(
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                for (g in Gender.entries) {
                    val selected = gender == g
                    AppCard(
                        modifier = Modifier.weight(1f),
                        onClick = { gender = g },
                        containerColor = if (selected) cs.primaryContainer else cs.surface,
                        borderColor = if (selected) cs.primary else cs.outlineVariant
                    ) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            CharacterAvatar(gender = g, stage = CharacterStage.SLACKER, size = 112.dp, showBadge = false)
                            Spacer(Modifier.height(8.dp))
                            Text(
                                text = g.label,
                                style = MaterialTheme.typography.titleMedium,
                                color = if (selected) cs.onPrimaryContainer else cs.onSurface
                            )
                        }
                    }
                }
            }
            Text(
                text = "Путь персонажа: Раздолбай → Новичок → Ученик → Знаток → Профи. Ошибки не портят внешний вид, растёт он только от занятий.",
                style = MaterialTheme.typography.bodyMedium,
                textAlign = TextAlign.Center,
                color = cs.onSurfaceVariant
            )
            PrimaryButton(text = "Начать", onClick = { onStart(gender) })
            Text(
                text = "Прогресс хранится на устройстве. Интернет не нужен.",
                style = MaterialTheme.typography.bodySmall,
                textAlign = TextAlign.Center,
                color = cs.onSurfaceVariant
            )
        }
    }
}
