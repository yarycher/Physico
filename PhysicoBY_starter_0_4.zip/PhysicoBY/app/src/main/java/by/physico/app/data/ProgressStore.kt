package by.physico.app.data

import android.content.Context

/**
 * Local progress storage for the offline-first prototype.
 * Later this can be replaced by Room + optional cloud sync without changing
 * the course/question model.
 */
data class ProgressSnapshot(
    val totalXp: Int = 0,
    val completedLessonIds: Set<String> = emptySet(),
    val correctAnswers: Int = 0,
    val totalAnswers: Int = 0,
    val mistakeQuestionIds: Set<String> = emptySet()
)

class ProgressStore(context: Context) {
    private val preferences = context.applicationContext
        .getSharedPreferences("physico_progress", Context.MODE_PRIVATE)

    fun load(): ProgressSnapshot = ProgressSnapshot(
        totalXp = preferences.getInt(KEY_XP, 0),
        completedLessonIds = preferences.getStringSet(KEY_COMPLETED, emptySet())
            ?.toSet() ?: emptySet(),
        correctAnswers = preferences.getInt(KEY_CORRECT, 0),
        totalAnswers = preferences.getInt(KEY_TOTAL, 0),
        mistakeQuestionIds = preferences.getStringSet(KEY_MISTAKES, emptySet())
            ?.toSet() ?: emptySet()
    )

    fun save(snapshot: ProgressSnapshot) {
        preferences.edit()
            .putInt(KEY_XP, snapshot.totalXp)
            .putStringSet(KEY_COMPLETED, snapshot.completedLessonIds.toSet())
            .putInt(KEY_CORRECT, snapshot.correctAnswers)
            .putInt(KEY_TOTAL, snapshot.totalAnswers)
            .putStringSet(KEY_MISTAKES, snapshot.mistakeQuestionIds.toSet())
            .apply()
    }

    companion object {
        private const val KEY_XP = "total_xp"
        private const val KEY_COMPLETED = "completed_lessons"
        private const val KEY_CORRECT = "correct_answers"
        private const val KEY_TOTAL = "total_answers"
        private const val KEY_MISTAKES = "mistake_question_ids"
    }
}
