package by.physico.app.data

data class Subject(
    val id: String,
    val title: String,
    val description: String,
    val topics: List<Topic>
)

data class Topic(
    val id: String,
    val title: String,
    val description: String,
    val lessons: List<Lesson> = emptyList()
)

data class Lesson(
    val id: String,
    val title: String,
    val estimatedMinutes: Int,
    val theory: String,
    val formula: String? = null,
    /** Guided practice inside the lesson. */
    val questions: List<Question> = emptyList(),
    /** Mandatory end-of-lesson assessment. Completion is blocked until it is passed. */
    val assessmentQuestions: List<Question> = emptyList(),
    val passingPercent: Int = 60
)

data class Question(
    val id: String,
    val prompt: String,
    val options: List<String>,
    val correctOptionIndex: Int,
    val explanation: String
)

data class UserProgress(
    val totalXp: Int = 0,
    val completedLessonIds: Set<String> = emptySet(),
    val answeredQuestionIds: Set<String> = emptySet(),
    val correctAnswers: Int = 0,
    val totalAnswers: Int = 0
)
