package by.physico.app.data

/** Demonstration content authored for the prototype; not an official RIKC question bank. */
object PhysicsCatalog {
    private val speedLesson = Lesson(
        id = "speed-basics",
        title = "Скорость и равномерное движение",
        estimatedMinutes = 7,
        theory = "Скорость показывает, какой путь тело проходит за единицу времени. " +
            "При равномерном движении скорость не меняется. Чтобы найти скорость, " +
            "нужно весь пройденный путь разделить на время движения.",
        formula = "v = s / t",
        questions = listOf(
            Question(
                id = "speed-practice-001",
                prompt = "Тело прошло 100 м за 10 с. Чему равна его средняя скорость?",
                options = listOf("5 м/с", "10 м/с", "20 м/с", "100 м/с"),
                correctOptionIndex = 1,
                explanation = "v = s / t = 100 м / 10 с = 10 м/с."
            ),
            Question(
                id = "speed-practice-002",
                prompt = "Какой путь пройдёт тело за 4 с со скоростью 3 м/с?",
                options = listOf("7 м", "12 м", "1,3 м", "24 м"),
                correctOptionIndex = 1,
                explanation = "Из v = s / t получаем s = v · t = 3 · 4 = 12 м."
            )
        ),
        assessmentQuestions = listOf(
            Question(
                id = "speed-test-001",
                prompt = "Автомобиль двигался равномерно и за 2 часа прошёл 120 км. Найди скорость.",
                options = listOf("40 км/ч", "60 км/ч", "120 км/ч", "240 км/ч"),
                correctOptionIndex = 1,
                explanation = "v = s / t = 120 км / 2 ч = 60 км/ч."
            ),
            Question(
                id = "speed-test-002",
                prompt = "Какое выражение позволяет найти время движения при известном пути и скорости?",
                options = listOf("t = s · v", "t = v / s", "t = s / v", "t = s + v"),
                correctOptionIndex = 2,
                explanation = "Из v = s / t выражаем время: t = s / v."
            ),
            Question(
                id = "speed-test-003",
                prompt = "Пешеход шёл со скоростью 2 м/с в течение 30 с. Какой путь он прошёл?",
                options = listOf("15 м", "28 м", "32 м", "60 м"),
                correctOptionIndex = 3,
                explanation = "s = v · t = 2 м/с · 30 с = 60 м."
            )
        )
    )

    val subject = Subject(
        id = "physics",
        title = "Физика",
        description = "Подготовка к ЦЭ и ЦТ Республики Беларусь",
        topics = listOf(
            Topic("mechanics", "Механика", "Кинематика, динамика, статика и законы сохранения", listOf(speedLesson)),
            Topic("molecular", "Молекулярная физика и термодинамика", "Молекулярное строение вещества, температура, давление и тепло"),
            Topic("electricity", "Электродинамика", "Электрический ток, электрические цепи и магнитное поле"),
            Topic("oscillations", "Колебания и волны", "Механические и электромагнитные колебания, волновые явления"),
            Topic("optics", "Оптика", "Геометрическая оптика и световые явления"),
            Topic("quantum", "Квантовая и атомная физика", "Фотоэффект, строение атома и атомного ядра")
        )
    )

    val allLessons: List<Lesson> = subject.topics.flatMap { it.lessons }
    val allQuestions: List<Question> = allLessons.flatMap { it.questions + it.assessmentQuestions }
}
