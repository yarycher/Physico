package by.physico.app.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.Replay
import androidx.compose.material.icons.filled.Quiz
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import by.physico.app.data.Lesson
import by.physico.app.data.PhysicsCatalog
import by.physico.app.data.ProgressSnapshot
import by.physico.app.data.ProgressStore
import by.physico.app.data.Question
import by.physico.app.data.Topic

private enum class MainTab(val title: String) {
    LEARN("Обучение"), REVIEW("Повторение"), TESTS("Тесты"), PROGRESS("Профиль")
}

private enum class LessonStage { THEORY, PRACTICE, ASSESSMENT, RESULT }

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PhysicoApp() {
    val context = LocalContext.current
    val progressStore = remember { ProgressStore(context) }
    var progress by remember { mutableStateOf(progressStore.load()) }
    var selectedTab by remember { mutableStateOf(MainTab.LEARN) }
    var openedLesson by remember { mutableStateOf<Lesson?>(null) }
    var reviewQuestion by remember { mutableStateOf<Question?>(null) }

    fun updateProgress(updated: ProgressSnapshot) {
        progress = updated
        progressStore.save(updated)
    }

    fun finishLesson(lesson: Lesson, correct: Int, total: Int, mistakes: Set<String>) {
        val firstCompletion = lesson.id !in progress.completedLessonIds
        updateProgress(
            progress.copy(
                totalXp = progress.totalXp + if (firstCompletion) correct * 10 + 20 else 0,
                completedLessonIds = progress.completedLessonIds + lesson.id,
                correctAnswers = progress.correctAnswers + correct,
                totalAnswers = progress.totalAnswers + total,
                mistakeQuestionIds = (progress.mistakeQuestionIds + mistakes) -
                    (lesson.questions + lesson.assessmentQuestions)
                        .filter { it.id !in mistakes }.map { it.id }.toSet()
            )
        )
        openedLesson = null
        selectedTab = MainTab.LEARN
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("Physico BY")
                        Text("Учись · Повторяй · Сдавай ЦЭ/ЦТ", style = MaterialTheme.typography.labelSmall)
                    }
                },
                navigationIcon = {
                    if (openedLesson != null || reviewQuestion != null) {
                        IconButton(onClick = { openedLesson = null; reviewQuestion = null }) {
                            Icon(Icons.Default.ArrowBack, contentDescription = "Назад")
                        }
                    }
                }
            )
        },
        bottomBar = {
            if (openedLesson == null && reviewQuestion == null) {
                NavigationBar {
                    MainTab.values().forEach { tab ->
                        NavigationBarItem(
                            selected = selectedTab == tab,
                            onClick = { selectedTab = tab },
                            icon = {
                                when (tab) {
                                    MainTab.LEARN -> Icon(Icons.Default.MenuBook, null)
                                    MainTab.REVIEW -> Icon(Icons.Default.Replay, null)
                                    MainTab.TESTS -> Icon(Icons.Default.Quiz, null)
                                    MainTab.PROGRESS -> Icon(Icons.Default.EmojiEvents, null)
                                }
                            },
                            label = { Text(tab.title) }
                        )
                    }
                }
            }
        }
    ) { padding ->
        when {
            openedLesson != null -> LessonFlow(
                lesson = openedLesson!!,
                modifier = Modifier.padding(padding),
                onFinish = ::finishLesson
            )
            reviewQuestion != null -> ReviewQuestionScreen(
                question = reviewQuestion!!,
                modifier = Modifier.padding(padding),
                onAnswer = { correct ->
                    val id = reviewQuestion!!.id
                    val updatedMistakes = if (correct) progress.mistakeQuestionIds - id
                        else progress.mistakeQuestionIds
                    updateProgress(
                        progress.copy(
                            correctAnswers = progress.correctAnswers + if (correct) 1 else 0,
                            totalAnswers = progress.totalAnswers + 1,
                            mistakeQuestionIds = updatedMistakes
                        )
                    )
                    reviewQuestion = null
                }
            )
            else -> when (selectedTab) {
                MainTab.LEARN -> LearningScreen(
                    modifier = Modifier.padding(padding), progress = progress,
                    onOpenLesson = { openedLesson = it }
                )
                MainTab.REVIEW -> ReviewScreen(
                    modifier = Modifier.padding(padding), progress = progress,
                    onOpenQuestion = { reviewQuestion = it }
                )
                MainTab.TESTS -> TestsScreen(
                    modifier = Modifier.padding(padding), onStart = {
                        openedLesson = PhysicsCatalog.allLessons.firstOrNull()
                    }
                )
                MainTab.PROGRESS -> ProgressScreen(Modifier.padding(padding), progress)
            }
        }
    }
}

@Composable
private fun LearningScreen(
    modifier: Modifier = Modifier,
    progress: ProgressSnapshot,
    onOpenLesson: (Lesson) -> Unit
) {
    LazyColumn(
        modifier = modifier.fillMaxSize().padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Spacer(Modifier.height(4.dp))
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                shape = RoundedCornerShape(24.dp)
            ) {
                Column(Modifier.padding(18.dp)) {
                    Text("Твой путь к ЦТ", style = MaterialTheme.typography.headlineSmall)
                    Text("Каждый урок заканчивается обязательным тестом на усвоение.")
                    Spacer(Modifier.height(12.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(20.dp)) {
                        Text("⭐ ${progress.totalXp} XP")
                        Text("📚 ${progress.completedLessonIds.size} уроков")
                    }
                }
            }
        }
        item { Text("Карта обучения", style = MaterialTheme.typography.titleLarge) }
        items(PhysicsCatalog.subject.topics) { topic ->
            TopicCard(topic, progress.completedLessonIds, onOpenLesson)
        }
        item {
            Text(
                "Сейчас доступен демонстрационный урок по механике. Остальные разделы будут наполняться по программе РИКЗ.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(Modifier.height(20.dp))
        }
    }
}

@Composable
private fun TopicCard(topic: Topic, completedLessons: Set<String>, onOpenLesson: (Lesson) -> Unit) {
    Card(modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp)) {
            Text(topic.title, style = MaterialTheme.typography.titleMedium)
            Text(topic.description, style = MaterialTheme.typography.bodySmall)
            Spacer(Modifier.height(8.dp))
            if (topic.lessons.isEmpty()) {
                Text("Материалы готовятся", color = MaterialTheme.colorScheme.primary)
            } else topic.lessons.forEach { lesson ->
                Row(
                    modifier = Modifier.fillMaxWidth().clickable { onOpenLesson(lesson) }.padding(vertical = 10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(Modifier.weight(1f)) {
                        Text(lesson.title, style = MaterialTheme.typography.bodyLarge)
                        Text(
                            "${lesson.estimatedMinutes} мин · ${lesson.questions.size} упражнений · тест ${lesson.assessmentQuestions.size} вопроса",
                            style = MaterialTheme.typography.labelSmall
                        )
                    }
                    Text(if (lesson.id in completedLessons) "✓ Пройдено" else "Начать",
                        color = MaterialTheme.colorScheme.primary)
                }
            }
        }
    }
}

@Composable
private fun LessonFlow(
    lesson: Lesson,
    modifier: Modifier = Modifier,
    onFinish: (Lesson, Int, Int, Set<String>) -> Unit
) {
    var stage by remember(lesson.id) { mutableStateOf(LessonStage.THEORY) }
    var questionIndex by remember(lesson.id) { mutableIntStateOf(0) }
    var selectedOption by remember(lesson.id, stage, questionIndex) { mutableIntStateOf(-1) }
    var checked by remember(lesson.id, stage, questionIndex) { mutableStateOf(false) }
    var practiceCorrect by remember(lesson.id) { mutableIntStateOf(0) }
    var testCorrect by remember(lesson.id) { mutableIntStateOf(0) }
    var mistakes by remember(lesson.id) { mutableStateOf(emptySet<String>()) }

    val isPractice = stage == LessonStage.PRACTICE
    val activeQuestions = when (stage) {
        LessonStage.PRACTICE -> lesson.questions
        LessonStage.ASSESSMENT -> lesson.assessmentQuestions
        else -> emptyList()
    }
    val current = activeQuestions.getOrNull(questionIndex)
    val totalQuestions = lesson.questions.size + lesson.assessmentQuestions.size
    val assessmentPercent = if (lesson.assessmentQuestions.isEmpty()) 100
        else testCorrect * 100 / lesson.assessmentQuestions.size

    Column(modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        when (stage) {
            LessonStage.THEORY -> {
                Text("Урок · 1 из 3", style = MaterialTheme.typography.labelLarge)
                LinearProgressIndicator(progress = { 0.33f }, modifier = Modifier.fillMaxWidth())
                Text(lesson.title, style = MaterialTheme.typography.headlineSmall)
                Text("Разберись в материале, затем потренируйся и пройди итоговый тест.")
                Text("Теория", style = MaterialTheme.typography.titleMedium)
                Text(lesson.theory, style = MaterialTheme.typography.bodyLarge)
                lesson.formula?.let { formula ->
                    Surface(color = MaterialTheme.colorScheme.secondaryContainer, shape = RoundedCornerShape(16.dp)) {
                        Text(formula, modifier = Modifier.fillMaxWidth().padding(20.dp),
                            style = MaterialTheme.typography.headlineMedium)
                    }
                }
                Spacer(Modifier.weight(1f))
                Button(onClick = { stage = if (lesson.questions.isEmpty()) LessonStage.ASSESSMENT else LessonStage.PRACTICE },
                    modifier = Modifier.fillMaxWidth()) { Text("Перейти к упражнениям") }
            }
            LessonStage.PRACTICE, LessonStage.ASSESSMENT -> {
                val stageTitle = if (isPractice) "Тренировка" else "Проверка знаний"
                val stageIndex = if (isPractice) 2 else 3
                Text("$stageTitle · этап $stageIndex из 3", style = MaterialTheme.typography.labelLarge)
                LinearProgressIndicator(
                    progress = {
                        val completedStages = if (isPractice) 0.33f else 0.66f
                        completedStages + (1f / 3f) * (questionIndex + 1).toFloat() /
                            activeQuestions.size.coerceAtLeast(1)
                    }, modifier = Modifier.fillMaxWidth()
                )
                Text("Вопрос ${questionIndex + 1} из ${activeQuestions.size}",
                    style = MaterialTheme.typography.labelLarge)
                if (current != null) {
                    Text(current.prompt, style = MaterialTheme.typography.titleLarge)
                    current.options.forEachIndexed { index, option ->
                        val chosen = selectedOption == index
                        OutlinedButton(
                            onClick = { if (!checked) selectedOption = index },
                            enabled = !checked,
                            modifier = Modifier.fillMaxWidth()
                        ) { Text(if (chosen) "●  $option" else option) }
                    }
                    if (checked) {
                        val correct = selectedOption == current.correctOptionIndex
                        Text(if (correct) "Верно!" else "Разберём ошибку",
                            color = if (correct) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error,
                            style = MaterialTheme.typography.titleMedium)
                        Text(current.explanation)
                        Button(onClick = {
                            questionIndex++
                            if (questionIndex >= activeQuestions.size) {
                                questionIndex = 0
                                if (isPractice) stage = LessonStage.ASSESSMENT
                                else stage = LessonStage.RESULT
                            }
                        }, modifier = Modifier.fillMaxWidth()) { Text("Далее") }
                    } else {
                        Button(
                            onClick = {
                                checked = true
                                if (selectedOption == current.correctOptionIndex) {
                                    mistakes = mistakes - current.id
                                    if (isPractice) practiceCorrect++ else testCorrect++
                                } else mistakes = mistakes + current.id
                            },
                            enabled = selectedOption >= 0,
                            modifier = Modifier.fillMaxWidth()
                        ) { Text("Проверить") }
                    }
                }
            }
            LessonStage.RESULT -> {
                val passed = assessmentPercent >= lesson.passingPercent
                Text(if (passed) "Урок усвоен! 🎉" else "Нужно немного повторить")
                Text("Итоговый тест", style = MaterialTheme.typography.headlineMedium)
                Text("Правильных ответов: $testCorrect из ${lesson.assessmentQuestions.size}")
                Text("Результат: $assessmentPercent% · проходной балл ${lesson.passingPercent}%")
                LinearProgressIndicator(progress = { assessmentPercent / 100f }, modifier = Modifier.fillMaxWidth())
                Text(if (passed) "Отличная работа! Урок можно завершить. Ошибки останутся в разделе повторения."
                    else "Урок пока не засчитан. Повтори теорию и попробуй тест ещё раз.")
                Spacer(Modifier.weight(1f))
                if (passed) {
                    Button(
                        onClick = { onFinish(lesson, practiceCorrect + testCorrect, totalQuestions, mistakes) },
                        modifier = Modifier.fillMaxWidth()
                    ) { Text("Завершить урок · +${(practiceCorrect + testCorrect) * 10 + 20} XP") }
                } else {
                    Button(onClick = {
                        stage = LessonStage.ASSESSMENT
                        questionIndex = 0
                        testCorrect = 0
                    }, modifier = Modifier.fillMaxWidth()) { Text("Повторить тест") }
                    OutlinedButton(onClick = { testCorrect = 0; stage = LessonStage.THEORY }, modifier = Modifier.fillMaxWidth()) {
                        Text("Вернуться к теории")
                    }
                }
            }
        }
    }
}

@Composable
private fun ReviewScreen(
    modifier: Modifier = Modifier,
    progress: ProgressSnapshot,
    onOpenQuestion: (Question) -> Unit
) {
    val questions = PhysicsCatalog.allQuestions.filter { it.id in progress.mistakeQuestionIds }
    LazyColumn(modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            Text("Работа над ошибками", style = MaterialTheme.typography.headlineMedium)
            Text("Ошибочные вопросы собираются здесь автоматически. Ответь правильно, чтобы убрать вопрос из списка.")
            Text("Осталось повторить: ${questions.size}", color = MaterialTheme.colorScheme.primary)
        }
        if (questions.isEmpty()) {
            item {
                Card { Column(Modifier.padding(18.dp)) {
                    Text("Пока всё чисто! ✨", style = MaterialTheme.typography.titleLarge)
                    Text("Ошибки из уроков и тестов появятся здесь. Возвращайся после новых занятий.")
                } }
            }
        } else items(questions) { question ->
            Card(modifier = Modifier.fillMaxWidth().clickable { onOpenQuestion(question) }) {
                Column(Modifier.padding(16.dp)) {
                    Text(question.prompt, style = MaterialTheme.typography.titleMedium)
                    Text("Нажми, чтобы решить ещё раз", color = MaterialTheme.colorScheme.primary)
                }
            }
        }
    }
}

@Composable
private fun ReviewQuestionScreen(question: Question, modifier: Modifier = Modifier, onAnswer: (Boolean) -> Unit) {
    var selected by remember(question.id) { mutableIntStateOf(-1) }
    var checked by remember(question.id) { mutableStateOf(false) }
    val correct = selected == question.correctOptionIndex
    Column(modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("Повторение", style = MaterialTheme.typography.labelLarge)
        Text(question.prompt, style = MaterialTheme.typography.headlineSmall)
        question.options.forEachIndexed { index, option ->
            OutlinedButton(onClick = { if (!checked) selected = index },
                enabled = !checked, modifier = Modifier.fillMaxWidth()) {
                Text(if (selected == index) "●  $option" else option)
            }
        }
        if (checked) {
            Text(if (correct) "Верно! Ошибка исправлена." else "Пока не получилось. Вопрос останется в повторении.",
                color = if (correct) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error)
            Text(question.explanation)
            Button(onClick = { onAnswer(correct) }, modifier = Modifier.fillMaxWidth()) { Text("Готово") }
        } else Button(onClick = { checked = true }, enabled = selected >= 0,
            modifier = Modifier.fillMaxWidth()) { Text("Проверить") }
    }
}

@Composable
private fun TestsScreen(modifier: Modifier = Modifier, onStart: () -> Unit) {
    Column(modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("Тренировки и тесты", style = MaterialTheme.typography.headlineMedium)
        Text("После каждого урока — обязательная проверка. Здесь будут тематические, смешанные и экзаменационные варианты.")
        Card {
            Column(Modifier.padding(16.dp)) {
                Text("Контрольный тест: механика", style = MaterialTheme.typography.titleMedium)
                Text("Открой урок, пройди тренировку и проверь знания в итоговом тесте: 3 вопроса, проходной результат 60%.")
                Spacer(Modifier.height(12.dp))
                Button(onClick = onStart, modifier = Modifier.fillMaxWidth()) { Text("Начать тест") }
            }
        }
        Card {
            Column(Modifier.padding(16.dp)) {
                Text("Ежедневное повторение", style = MaterialTheme.typography.titleMedium)
                Text("Подборка формул и вопросов из уже пройденных тем — следующий этап разработки.")
            }
        }
        Text("Задания в текущей версии авторские и не являются официальными материалами РИКЗ.",
            style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun ProgressScreen(modifier: Modifier = Modifier, progress: ProgressSnapshot) {
    val accuracy = if (progress.totalAnswers == 0) 0 else progress.correctAnswers * 100 / progress.totalAnswers
    Column(modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("Твой прогресс", style = MaterialTheme.typography.headlineMedium)
        StatCard("Опыт", "${progress.totalXp} XP")
        StatCard("Пройдено уроков", progress.completedLessonIds.size.toString())
        StatCard("Точность ответов", "$accuracy%")
        StatCard("Заданий на повторение", progress.mistakeQuestionIds.size.toString())
        Text("Прогресс хранится локально на устройстве.", style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun StatCard(title: String, value: String) {
    Card(modifier = Modifier.fillMaxWidth()) {
        Row(Modifier.fillMaxWidth().padding(18.dp), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(title, style = MaterialTheme.typography.titleMedium)
            Text(value, style = MaterialTheme.typography.titleLarge, color = MaterialTheme.colorScheme.primary)
        }
    }
}
