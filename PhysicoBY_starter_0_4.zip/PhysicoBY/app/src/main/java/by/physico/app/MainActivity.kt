package by.physico.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import by.physico.app.ui.PhysicoApp
import by.physico.app.ui.theme.PhysicoTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            PhysicoTheme {
                PhysicoApp()
            }
        }
    }
}
